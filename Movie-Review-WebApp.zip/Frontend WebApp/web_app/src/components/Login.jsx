import React, { Component } from 'react';
import { Form, Button } from 'reactstrap';

function signIn() {
    //check if user exists
    //save the user credentials locally (security)
    window.location.replace("http://localhost:3000");
}

export default class Login extends Component {
    render() {
    return (
      <div style={{background: "white", position: "fixed", top: "50%", left: "50%", width: "30em", height: "18em", marginTop: "-9em", marginLeft: "-15em", border: "1px"}}>
          <h1>Login</h1>
          <Form>
              <div style={{marginBottom: "40px", marginRight: "6em", float: "right"}}>
            <label>Korisničko ime: </label>
            <input type="text" 
          className="form-control" aria-describedby="addon-wrapping" size="30"
          />
          </div>
          <div style={{marginRight: "6em", float: "right"}}>
            <label>Lozinka: </label>
            <input type="password" className="form-control2" aria-describedby="addon-wrapping2" size="30"
          />
          </div>
          <a href="http://localhost:3000/register" style={{position: "absolute", left: "70px", bottom:"30px"}}>Registracija</a>
          <Button onClick={signIn} style={{position: "absolute", right: "50px", bottom: "30px", width: "100px"}}>Login</Button>
          </Form>
      </div>
    );
  } 
}