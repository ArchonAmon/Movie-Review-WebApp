import React, { Component } from 'react';
import {Button } from 'reactstrap';
import MovieLibrary from "./MovieLibrary"


var IMDb_url = "//www.imdb.com/title/"
var urlExists = false;

function searchMovie() {   
  let i;
  let search = "";
  for (i = 0; i < document.getElementById("addon-wrapping2").value.split(" ").length; i++) {
    if (i !== 0) {
      search += "+" + document.getElementById("addon-wrapping2").value.split(" ")[i];
    }
    else search += document.getElementById("addon-wrapping2").value.split(" ")[i];
  }
  if (search !== "") window.location.replace("http://localhost:3000/movies/userSearchResult/" + search);
}


function refreshLibrary() {
  let box = "sorts"
  if (document.getElementById(box).value === "Date viewed") window.location.replace("http://localhost:3000/movies/byDateViewed");
  else if (document.getElementById(box).value === "My rating") window.location.replace("http://localhost:3000/movies/byMyRating");
  else if (document.getElementById(box).value === "IMDb rating") window.location.replace("http://localhost:3000/movies/byIMDbRating");
  else if (document.getElementById(box).value === "-") window.location.replace("http://localhost:3000");
  else {
    console.log(document.getElementById(box));
    window.location.replace("http://localhost:3000/movies/by" + document.getElementById(box).value);
  }
}

async function urlCheck() {
  if (!document.getElementById("addon-wrapping").value.includes(IMDb_url)) {
    alert("Ovo nije IMDb url!");
  }
  else {
  urlExists = false;
  tempMovie.map (m => {
  if(m.link === document.getElementById("addon-wrapping").value) {
  urlExists = true;
  alert("Film je već dodan!");
  }
  return null;
})
  if (urlExists === false) {
    //add movie
    var currentLocation = window.location;
    var movieLinkString = document.getElementById("addon-wrapping").value;
    await fetch(currentLocation+"/movies", {
      method: "POST", 
      headers: {
        "Accept" : "application/json",
        "Content-Type" : "application/json"
      },
      body: movieLinkString
    }).then(response => response.text())
    .then(json => console.log(json))
    .then(await new Promise(r => setTimeout(r, 3000)))
    .then(window.location.replace("http://localhost:3000"));

  }
  }
}

let tempMovie;


//class component
export default class Top extends Component {

  state = {
    isLoading: true,
    Movies: [],
  }

  async componentDidMount() {
    let link = "";
    if (window.location.href === "http://localhost:3000/") link = '/movies';
    else link = "/movies" + window.location.href.slice(28);
    const response = await fetch(link);
    const body = await response.json();
    this.setState({Movies :body, isLoading: false});
  }


    render() {
      const {Movies, isLoading} = this.state;
      if (isLoading) return (<div>Loading...</div>);
      window.location.href === "http://localhost:3000/" ? tempMovie = Movies.mov : tempMovie = Movies;       //was tempMovie = Movies
      return(
      <div className="top" style={{width: 'max', height: '125px', backgroundImage: "url(https://acrediteounao.com/wp-content/uploads/2017/02/filmes.png)"}}>
          <div className="searchBox" style={{zIndex: 2}}>   
        <input type="text" 
          className="form-control" placeholder="Postavite IMDb url filma"  id ="addon-wrapping"
          aria-label="url" aria-describedby="addon-wrapping" size="40"
          />
      </div>
      <div className="searchButton">
          <Button type="button" color="primary" onClick={urlCheck}>Dodaj Film</Button>
         </div>
         <div type="sortDropbox" className="sortDropbox" style={{position: "absolute", top: "100px", left:"0", width: "300px"}}>
         <label for="sorts" style={{color: "white"}}>Sortiraj po:</label>
            <select id="sorts" value = {window.location.href.includes("byIMDb")?"IMDb rating":window.location.href.includes("byMy")?"My rating":window.location.href.includes("byYear")?"Year":
            window.location.href.includes("byTitle")?"Title":window.location.href.includes("byDuration")?"Duration":window.location.href.includes("byDateViewed")?"Date viewed":"-" } onChange={refreshLibrary}>
              <option value="-">-</option>
              <option value="Date viewed">Datumu Gledanja</option>
              <option value="Title">Naslovu</option>
              <option value="IMDb rating">IMDb Ocjenama</option>
              <option value="My rating">Mojim Ocjenama</option>
              <option value="Year">Godini</option>
              <option value="Duration">Trajanju</option>
            </select>
         </div>
         <div type="searchDropbox" className="searchDropbox" style={{position: "absolute", top: "100px", right:"0", width: "400px"}}>
         <input type="text" 
          className="form-control" placeholder="Pretraži film, glumca, redatelja..."  id ="addon-wrapping2"
          aria-label="url" aria-describedby="addon-wrapping" size="30" style={{marginRight:"3px"}}
          />
          <Button type="button" color="primary" onClick={searchMovie}>Traži</Button>
         </div>

         </div>
      );
    }
  }