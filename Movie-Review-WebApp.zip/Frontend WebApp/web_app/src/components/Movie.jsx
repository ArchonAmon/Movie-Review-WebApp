import React, { Component } from 'react';
import {Col, Input, Label, Form} from "reactstrap"



function setDate() {
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');   //January is 0
  var yyyy = today.getFullYear();
  today = dd + "." + mm + "." + yyyy; 
  document.getElementById("dateViewed").value = today;
}

function durationSet(dur) {
  return String(dur) + " min";
}

function goToHomeScreen() {
  window.location.replace("http://localhost:3000");
}

async function deleteMovie() {
  var currentLocation = window.location;
  await fetch(currentLocation, {
    method: "DELETE", 
    headers: {
      "Accept" : "application/json",
      "Content-Type" : "aplication/json"
    }
  })
  window.location.replace("http://localhost:3000");
}

async function checkAndPutData() {
  var retry = 0;
  if (document.getElementById("year").value.toString().length!==4) {
    alert("Godina nije valjanog formata");
    retry = 1;
  } 
  if (document.getElementById("imdb_rating").value < 0 || document.getElementById("imdb_rating").value > 10) {
   alert("IMDb ocjena mora biti između 0 i 10");
   retry = 1;
  }
  if (document.getElementById("myRating").value < 0 || document.getElementById("myRating").value > 10) {
    alert("Ocjena mora biti između 0 i 10");
    retry = 1;
  } 
  if (document.getElementById("myRating").value.toString() === "") {
     alert("Moja ocjena mora biti dana");
     retry = 1;
  }
  if (document.getElementById("dateViewed").value.toString() === "") {
    alert("Datum gledanja mora biti dan");
    retry = 1;
  }
  if (document.getElementById("title").value.toString() === "") {
    alert("Ime filma mora biti dano");
    retry = 1;
  }
  if (document.getElementById("review").value.length > 10000) {
    alert("Recenzija filma je predugačka");
    retry = 1;
  }
  if (document.getElementById("title").value.length > 10000) {
    alert("Naslov filma je predugačak");
    retry = 1;
  }
  if (document.getElementById("director").value.length > 10000) {
    alert("Polje režisera je predugačko");
    retry = 1;
  }
  if (document.getElementById("writer").value.length > 10000) {
    alert("Polje scenarista je predugačko");
    retry = 1;
  }
  if (document.getElementById("actors").value.length > 10000) {
    alert("Polje glumaca je predugačko");
    retry = 1;
  }
  if (document.getElementById("categories").value.length > 10000) {
    alert("Polje kategorija je predguačko");
    retry = 1;
  }
  if (document.getElementById("languages").value.length > 10000) {
    alert("Polje jezika je predugačko");
    retry = 1;
  }
  if (document.getElementById("countries").value.length > 10000) {
    alert("Polje zemalja je predugačko");
    retry = 1;
  }
  if (document.getElementById("poster").value.length > 10000) {
    alert("Polje url slike je predugačko");
    retry = 1;
  }
  if (document.getElementById("imdb_rating").value.length > 100) {
    alert("Polje IMDb ocjena je preduačko");
    retry = 1;
  }
  if (document.getElementById("duration").value.length > 100) {
    alert("Polje trajanje je predugačko");
    retry = 1;
  }
  if (document.getElementById("dateViewed").value.length > 100) {
    alert("Polje datum gledanja je predugačko");
    retry = 1;
  }

  if (retry === 0) {
    var currentLocation = window.location;
    await fetch(currentLocation, {
      method: "PUT", 
      headers: {
        "Accept" : "application/json",
        "Content-Type" : "application/json"
      },
      body: JSON.stringify({
        "id": tempMovie.id,
        "name": document.getElementById("title").value,
        "poster_url": document.getElementById("poster").value,
        "link": tempMovie.link,
        "imdb_rating": document.getElementById("imdb_rating").value,
        "year": document.getElementById("year").value,
        "review": document.getElementById("review").value,
        "dateViewed": document.getElementById("dateViewed").value.split(".")[2] + "-" + document.getElementById("dateViewed").value.split(".")[1] + "-" + document.getElementById("dateViewed").value.split(".")[0],  //call function to parse a proper date
        "myRating": document.getElementById("myRating").value,
        "duration": document.getElementById("duration").value,
        "countries": document.getElementById("countries").value,
        "languages": document.getElementById("languages").value,
        "categories": document.getElementById("categories").value,
        "directors": document.getElementById("director").value,
        "writers": document.getElementById("writer").value,
        "actors": document.getElementById("actors").value,
        "movieAdded": true,
    })
    }).then(response => response.json())
    .then(window.location.replace("http://localhost:3000"));
  }
  
}

let tempMovie =  {
  "id": null,
  "name": "",
  "poster_url": "",
  "link": "",
  "imdb_rating": 0,
  "year": 0,
  "review": "",
  "dateViewed": "",
  "myRating": 0,
  "duration": 0,
  "director": "",
  "writer": "",
  "actors": "",
  "categories": "",
  "languages": "",
  "countries": "",
  "movieAdded": true,
  "user": ""    //user must remain the same
  }

export default class Movie extends Component {


  constructor(props){
    super(props)

    this.state = { 
      isLoading :false,
      Movie : [],
     }
  } 
  

  async componentDidMount() {
    var currentLocation = window.location;
    const response = await fetch(currentLocation);      //looks for the current url and fetches data by using the way it was mapped
    const body = await response.json();
    this.setState({Movie: body, isLoading: false});
  }
  render() {
    const {Movie, isLoading} = this.state;
    tempMovie.id = Movie.id;                          //this is where all movie attributes are temporarly placed
    tempMovie.user = Movie.user;                      //this is for security
    tempMovie.link = Movie.link;
    if (isLoading) return (<div>Loading...</div>);
    return(
      <div class="UpdateMovieScreen" style={{width: 'max', backgroundColor: "white", display: "flex", flexFlow: "column", height: "100vh"}}>
      <div id = "topIForm">
              <div className="imageAndUrl" style={{float: "left"}}>
      <img id={Movie.id} src={Movie.poster_url} alt={Movie.name} style={{float: "left", width: "225px", height: '300px', marginTop: "50px", marginRight: "50px", marginLeft: "50px", marginBottom: "0px"}}></img>
      <br></br>
      <label style={{float:"left", marginTop:"50px", width: "80px", marginLeft: "5px"}}>url slike: </label>
        <input id="poster" type="text" defaultValue={Movie.poster_url} size="30" style={{float:"left", marginTop:"50px", marginRight:"40px"}}></input>
      <br></br>
      <button type="button" id="checkData" onClick={checkAndPutData} style={{marginTop:"50px", width:"100px", height:"30px", marginRight:"5px"}}>Ažuriraj film</button>
      <button type="button" id="cancel" onClick={goToHomeScreen} style={{marginTop:"50px", width:"70px"}}>Poništi</button>
      <br></br>
      <button style={{marginTop:"4px"}}><img id="deleteButton" onClick={deleteMovie} style={{height:"30px", width:"30px"}} src="https://cdn2.iconfinder.com/data/icons/finance-2-25/48/68-512.png" alt="Delete movie"></img>
</button>
      </div>
      <div style={{float: "left", backgroundColor: "white"}}>
      
        <Form style={{backgroundColor: "white", marginTop: "50px", marginLeft: "100px"}}>
        <div style={{float:"left"}}>
        <div style={{float:"left"}}>
        <label style={{width:"50px"}}>Naslov: </label>
        <input type="text" id="title" size="40" defaultValue={Movie.name} style={{}}></input>
        </div>
        
        <div style={{float:"left", marginLeft: "100px"}}>
        <label style={{width:"50px"}}>Godina:  </label>
        <input type="text" size="7" id="year" defaultValue={Movie.year} style={{}}></input>
        </div>

        <div style={{float: "left", marginLeft: "100px"}}>
        <label style={{width:"100px"}}>IMDb ocjena: </label>
        <input type="text" size="7" id="imdb_rating" defaultValue={Movie.imdb_rating} style={{}}></input>
        </div>
        </div>

        <div style={{float: "left", marginTop: "50px", marginLeft: "100px", clear: "both"}}>
        <div style={{float:"left"}}>
        <label style={{width:"75px"}}>Redatelji: </label>
        <input type="text" id="director" size="30" defaultValue={Movie.directors} style={{}}></input>
        </div>

        <div style={{float:"left", marginLeft: "100px"}}>
        <label style={{width:"75px"}}>Scenaristi: </label>
        <input type="text" id="writer" size="30" defaultValue={Movie.writers} style={{}}></input>
        </div>
        </div>

        <div style={{float: "left", marginTop: "50px", marginLeft: "50px", clear: "both"}}>
        <label style={{width:"60px"}}>Glumci: </label>
        <input id="actors" defaultValue={Movie.actors} type="text" size="100" style={{}}></input>
        </div>

        <div style={{float: "left", marginTop: "50px", marginLeft: "0px", clear: "both"}}>
        <div style={{float:"left"}}>
        <label style={{width:"75px"}}>Kategorije: </label>
        <input type="text" id="categories" size="30" defaultValue={Movie.categories} style={{}}></input>
        </div>

        <div style={{float:"left", marginLeft: "50px"}}>
        <label style={{width:"75px"}}>Jezici: </label>
        <input type="text" id="languages" size="15" defaultValue={Movie.languages} style={{}}></input>
        </div>

        <div style={{float:"left", marginLeft: "50px"}}>
        <label style={{width:"75px"}}>Države: </label>
        <input type="text" id="countries" size="15" defaultValue={Movie.countries} style={{}}></input>
        </div>
        </div>

        <div style={{float: "left", marginTop: "50px", marginLeft: "70px", clear: "both"}}>
        <div style={{float: "left"}}>
        <label style={{width:"85px"}}>Moja ocjena: </label>
        <input id="myRating" type="text" size="7" defaultValue={Movie.myRating/*===0?"":Movie.myRating*/} style={{}}></input>
        </div>

        <div style={{float: "left", marginLeft: "60px"}}>
        <label style={{width: "100px"}}>Datum gledanja: </label>
        <input id="dateViewed" type="text" size="10" defaultValue={setTimeout(function()
        {
          var c = Movie.dateViewed;
          var d = String(c);
          var m = d.substr(8, 2) + "." + d.substr(5, 2) + "." + d.substr(0 , 4);
          document.getElementById("dateViewed").value = m;
        }, 1)} 
        style={{}}></input>
        <button type="button" onClick={setDate} style={{}}>Today</button>
        </div>

        <div style={{float:"left", marginLeft: "60px"}}>
        <label style={{width:"20px"}}>Trajanje: </label>
        <input type="text" id="duration" size="2" defaultValue={Movie.duration} style={{}}></input>
        <label style={{width:"15px"}}>min</label>
        </div>
        </div>

      <div style={{float: "left", marginTop: "50px", clear: "both"}}>
        <Label for="review" sm={2}>Recenzija:</Label>
        <Col sm={10}>
          <Input style={{width:"800px", height:"150px"}} defaultValue={Movie.review} type="textarea" name="text" id="review" />
        </Col>
      </div>
    </Form>
    </div>
      </div>
       </div>
    );
  }
}
