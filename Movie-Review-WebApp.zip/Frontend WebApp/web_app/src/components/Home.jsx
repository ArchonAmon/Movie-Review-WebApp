import React, { Component } from 'react';
import Top from './Top';
import MovieLibrary from './MovieLibrary';

export default class Home extends Component {
    render() {
    return (
      <div className="Home" id="Home" style={{height:"100%"}}>
        <Top></Top>
        <MovieLibrary id="library"></MovieLibrary>
      </div>
    );
  }
  }