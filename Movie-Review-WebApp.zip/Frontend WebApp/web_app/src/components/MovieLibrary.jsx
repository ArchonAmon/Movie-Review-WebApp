import React, { Component } from 'react';
import {Button } from 'reactstrap';


//checks if the movie has been added (the movie added flag will be true if the movie was added in the add movie screen) (currently not being used)
function checkMovieAdded(movieAdded, poster_url) {
  //if (movieAdded === false) return "Movie not added";
  //else 
 return poster_url;
}


function searchStatistics() {

  if (window.location.href !== "http://localhost:3000/") {
    alert("Statistiku je moguće gledati samo na prvoj stranici");
    return;
  }
  if (document.getElementById("first column selector").value === "-") {
    alert("Prvi stupac mora biti odabran");
    return;
  }
  if (document.getElementById("second column selector").value === "-") {
    alert("Drugi stupac mora biti odabran");
    return;
  }

  if (document.getElementById("first column selector").value === "Najbolji Glumac" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[0];
  }
  if (document.getElementById("first column selector").value === "Najbolji Glumac" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[1];
  }
  if (document.getElementById("first column selector").value === "Najbolji Redatelj" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[2];
  }
  if (document.getElementById("first column selector").value === "Najbolji Redatelj" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[3];
  }
  if (document.getElementById("first column selector").value === "Najbolji Scenarist" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[4];
  }
  if (document.getElementById("first column selector").value === "Najbolji Scenarist" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[5];
  }

  if (document.getElementById("first column selector").value === "Najgori Glumac" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[6];
  }
  if (document.getElementById("first column selector").value === "Najgori Glumac" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[7];
  }
  if (document.getElementById("first column selector").value === "Najgori Redatelj" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[8];
  }
  if (document.getElementById("first column selector").value === "Najgori Redatelj" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[9];
  }
  if (document.getElementById("first column selector").value === "Najgori Scenarist" && document.getElementById("second column selector").value === "Po IMDb Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[10];
  }
  if (document.getElementById("first column selector").value === "Najgori Scenarist" && document.getElementById("second column selector").value === "Po Mojim Ocjenama") {
    document.getElementById("Statistics Results").value = stat.split(";")[11];
  }
  
  

}

let stat;


export default class MovieLibrary extends Component {

  state = {
    isLoading: true,
    Movies: [],
  }

  async componentDidMount() {
    let link = "";
    if (window.location.href === "http://localhost:3000/") link = '/movies';
    const response = await fetch(link);          //fetch depending on the current url
    const body = await response.json();
    this.setState({Movies :body, isLoading: false});
  }


    render() {
      const {Movies, isLoading} = this.state;
      const m = Movies.mov;
      stat = Movies.statistics;
      if (isLoading) return (<div>Loading...</div>);
      return(
      <div className="movieLibrary" id="library" style={{backgroundImage: "url(https://serfob.s3.amazonaws.com/media/dark-light-diamond-black-background341-ea58-4f38-872a-46973a25c8ba.png)", width: "max", backgroundRepeat: "repeat-y", height: "max"}}> 
      {
        window.location.href=="http://localhost:3000/"? m.map (movie => //place a link in the background url, also remove movie.name if necessary
        <div style={{float: "left", width: "150px", height: '200px', margin: "50px"}}>
      <a href={"/movies/" + movie.id}>
          <img id={movie.id} class={movie.id} src={checkMovieAdded(movie.movieAdded, movie.poster_url)} alt={movie.name} style={{float: "left", width: "150px", height: '200px'}}>
        
          </img>
          </a>
          <div style={{color: "white"}}>
          {movie.name}
          </div>
          
          </div>
      )
      :Movies.map (movie => //place a link in the background url
          <div style={{float: "left", width: "150px", height: '200px', margin: "50px"}}>
        <a href={"/movies/" + movie.id}>
            <img id={movie.id} src={checkMovieAdded(movie.movieAdded, movie.poster_url)} alt={movie.name} style={{float: "left", width: "150px", height: '200px'}}>
          
            </img>
            </a>

            <div id={movie.id + " box"} style={{color: "white"}}>
            {window.location.href.includes("byTitle") ? movie.name : window.location.href.includes("userSearchResult") ? movie.name : window.location.href.includes("byIMDbRating") ? movie.imdb_rating : window.location.href.includes("byMyRating") ? movie.myRating :
            window.location.href.includes("byYear") ? movie.year : window.location.href.includes("byDuration") ? movie.duration + " min" :  
            setTimeout(function()
            {
              var c = movie.dateViewed;
              var d = String(c);
              var m = d.substr(8, 2) + "." + d.substr(5, 2) + "." + d.substr(0 , 4);
              document.getElementById(movie.id + " box").innerText = m;
            }, 0)}
            </div>

            </div>
        )
      }
      <div className="searchStatistics" style={{position: "absolute", top: "0px", right:"0", width: "400px"}}>
         <select id="first column selector">
              <option value="-">-</option>
              <option value="Najbolji Glumac">Najbolji Glumac</option>
              <option value="Najbolji Redatelj">Najbolji Redatelj</option>
              <option value="Najbolji Scenarist">Najbolji Scenarist</option>
              <option value="Najgori Glumac">Najgori Glumac</option>
              <option value="Najgori Redatelj">Najgori Redatelj</option>
              <option value="Najgori Scenarist">Najgori Scenarist</option>
            </select>
            <select id="second column selector" style={{marginLeft: "1px"}}>
              <option value="-">-</option>
              <option value="Po IMDb Ocjenama">Po IMDb Ocjenama</option>
              <option value="Po Mojim Ocjenama">Po Mojim Ocjenama</option>
            </select>
            <Button type="button" color="primary" style={{marginLeft: "3px"}} onClick={searchStatistics}>Traži</Button>
            </div>

          <div style={{position: "absolute", top: "28px", right:"0", width: "400px"}}>
            <input type="text" 
          className="form-control" disabled="true" placeholder="Rezultati Statistike" id ="Statistics Results"
          aria-label="url" aria-describedby="addon-wrapping" size="30" style={{marginRight:"3px"}}
          />
         </div>
         </div>
      );
    }
  } 




