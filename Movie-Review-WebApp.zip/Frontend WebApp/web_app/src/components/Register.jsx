import React, { Component } from 'react';
import { Form, Button } from 'reactstrap';


async function signUp() {
    if (document.getElementById("username").value.length < 4) {
      alert("Korisničko ime mora imati barem 4 znaka!");
    }
    if (document.getElementById("password").value !== document.getElementById("confirmPassword").value) {
      alert("Polje Lozinka i Potvrdi lozinku nisu isti!");
      return
    }
    if (document.getElementById("password").value.length < 4) {
      alert("Lozinka mora imati barem 4 znaka!");
      return
    }
    var re = /\S+@\S+\.\S+/;
    if (re.test(document.getElementById("email").value) === false) {
      alert("Krivi email format!");
      return
    }


    var currentLocation = window.location;

    await fetch(currentLocation, {
      method: "POST", 
      headers: {
        "Accept" : "application/json",
        "Content-Type" : "application/json"
      },
      body: JSON.stringify({
        "id": 0,
        "username": document.getElementById("username").value,
        "password": document.getElementById("password").value,
        "email": document.getElementById("email").value
    })
    }).then(response => response.text())
    .then(body=>{if(body === "User registered") {               //the backend response is logged and if it's ok the use is redirected to the site
            //authentication steps
            window.location.replace("http://localhost:3000");
                }
                 else {
                  alert(body);                                  //if not, then the response is printed as an alert
                 } })

}


export default class Register extends Component {
    render() {
    return (
        <div style={{background: "white", position: "fixed", top: "50%", left: "50%", width: "30em", height: "21em", marginTop: "-9em", marginLeft: "-15em", border: "1px"}}>
        <h1>Registracija</h1>
        <Form>
            <div style={{marginBottom: "30px", marginRight: "6em", float: "right"}}>
          <label>Korisničko ime: </label>
          <input type="text" 
        className="form-control" id="username" aria-describedby="addon-wrapping" size="30"
        />
          </div>
        <div style={{marginBottom: "30px", marginRight: "6em", float: "right"}}>
            <label>e-mail adresa: </label>
            <input id="email" className="form-control2" aria-describedby="addon-wrapping2" size="30"
          />
          </div>
        <div style={{marginBottom: "10px", marginRight: "6em", float: "right"}}>
            <label>Lozinka: </label>
            <input type="password" id="password" className="form-control2" aria-describedby="addon-wrapping2" size="30"
          />
        </div>
        <div style={{marginRight: "6em", float: "right"}}>
            <label>Potvrdi lozinku: </label>
            <input type="password" id="confirmPassword" className="form-control3" aria-describedby="addon-wrapping3" size="30"
          />
        </div>
        <Button onClick={signUp} style={{position: "absolute", right: "14em", bottom: "30px", width: "100px"}}>Registracija</Button>
        </Form>
    </div>
    );
  }
  }