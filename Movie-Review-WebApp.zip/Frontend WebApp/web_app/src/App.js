import React, { Component } from 'react';
import { BrowserRouter as Router,Switch,Route } from "react-router-dom"
import './App.css';
import Home from "./components/Home";
import Login from './components/Login';
import Movie from './components/Movie';
import Register from './components/Register';


class App extends Component {
  render() {
  return (
    <div className="App">
        <Router className="Router">
      <Switch>
        <Route path="/login" exact={true}><Login></Login></Route>
        <Route path="/register" exact={true}><Register></Register></Route>
        <Route path="/" exact={true}><Home></Home></Route>
        <Route path="/movies/byIMDbRating" exact={true}><Home></Home></Route>
        <Route path="/movies/byMyRating" exact={true}><Home></Home></Route>
        <Route path="/movies/byYear" exact={true}><Home></Home></Route>
        <Route path="/movies/byTitle" exact={true}><Home></Home></Route>
        <Route path="/movies/byDateViewed" exact={true}><Home></Home></Route>
        <Route path="/movies/byDuration" exact={true}><Home></Home></Route>
        <Route path="/movies/userSearchResult/:name" exact={true}><Home></Home></Route>
        <Route path="/movies/:id" exact={true}><Movie></Movie></Route>
      </Switch>
    </Router>
  </div>

  );
}
}


export default App;




/*
class App extends Component {
  render() {
  return (
    <div className="App" style={{flex: 1, height: "100%", minHeight: "100%"}}>
      <Top></Top>
      <MovieLibrary></MovieLibrary>
    </div>
  );
}
}
*/