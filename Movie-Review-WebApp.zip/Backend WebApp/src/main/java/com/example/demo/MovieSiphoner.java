package com.example.demo;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;


public class MovieSiphoner {            //takes the IMDb web address and creates a new movie

    int temp;
    LinkedHashSet<String> Categories = new LinkedHashSet<>();
    LinkedHashSet<String> Languages = new LinkedHashSet<>();
    LinkedHashSet<String> Countries = new LinkedHashSet<>();
    LinkedHashSet<String> Directors = new LinkedHashSet<>();
    LinkedHashSet<String> Actors = new LinkedHashSet<>();
    LinkedHashSet<String> Writers = new LinkedHashSet<>();
    String IMDb_rating;
    String duration;
    String poster_url;
    String title;
    String year;
    String id;
    boolean movieAdded = false;         //the rating and date fields are still empty
    boolean EOL = false;
    int i;
    int counter = 0;

    public MovieSiphoner(String link) {
        try {
            Document doc = Jsoup.connect(link).get();
            String HTML = doc.html();           //save the document as HTML



            try {

                if (HTML.contains("<h4 class=\"inline\">Director:</h4>") || HTML.contains("<h4 class=\"inline\">Directors:</h4>")) {
                    if (HTML.contains("<h4 class=\"inline\">Director:</h4>")) {
                        temp = HTML.indexOf("<h4 class=\"inline\">Director:</h4>");
                    } else temp = HTML.indexOf("<h4 class=\"inline\">Directors:</h4>");
                    counter = 0;
                    char[] c = new char[300];
                    for (i = temp; counter <= 2; i++) {
                        if (HTML.charAt(i) == '>') counter++;                 //looking where director name starts
                    }
                    counter = 0;
                    for (; HTML.charAt(i) != '<'; i++) {
                        c[counter] = HTML.charAt(i);
                        counter++;
                    }
                    Directors.add(new String(c).trim());

                    char[] cha = new char[300];
                    counter = 0;
                    for (; counter <= 1; i++) {
                        if (HTML.charAt(i) == '>') counter++;                 //looking where director #2 name starts
                        if (HTML.charAt(i) == '\n') {
                            EOL = true;
                            break;
                        }
                    }
                    counter = 0;
                    if (EOL == false) {
                        for (; HTML.charAt(i) != '<'; i++) {
                            cha[counter] = HTML.charAt(i);
                            counter++;
                        }
                        Directors.add(new String(cha).trim());              //change

                        char[] ch = new char[300];
                        counter = 0;
                        for (; counter <= 1; i++) {
                            if (HTML.charAt(i) == '>')
                                counter++;                 //looking where director #3 name starts
                            if (HTML.charAt(i) == '\n') {
                                EOL = true;
                                break;
                            }
                        }
                        counter = 0;
                        if (EOL == false) {
                            for (; HTML.charAt(i) != '<'; i++) {
                                ch[counter] = HTML.charAt(i);
                                counter++;
                            }
                            Directors.add(new String(ch).trim());              //change
                        }
                    }
                } else //send unavailable to frontend
                {
                    //Director = "Unavailable";
                }

            } catch (Exception e) {
                //Director = "Unavailable";
            }



            try {

            if (HTML.contains("<h4 class=\"inline\">Writer:</h4>") || HTML.contains("<h4 class=\"inline\">Writers:</h4>")) {
                if (HTML.contains("<h4 class=\"inline\">Writer:</h4>")) {
                    temp = HTML.indexOf("<h4 class=\"inline\">Writer:</h4>");
                }
                else temp = HTML.indexOf("<h4 class=\"inline\">Writers:</h4>");
                counter = 0;
                EOL = false;
                char[] c = new char[300];
                for (i = temp; counter <= 2; i++) {
                    if (HTML.charAt(i) == '>') counter++;                 //looking where writer name starts
                }
                counter = 0;
                for (; HTML.charAt(i) != '<'; i++) {
                    c[counter] = HTML.charAt(i);
                    counter++;
                }
                Writers.add(new String(c).trim());

                char[] cha = new char[300];
                counter = 0;
                for (; counter <= 1; i++) {
                    if (HTML.charAt(i) == '>') counter++;                 //looking where writer #2 name starts
                    if (HTML.charAt(i) == '\n') {
                        EOL = true;
                        break;
                    }
                }
                counter = 0;
                if (EOL == false) {
                    for (; HTML.charAt(i) != '<'; i++) {
                        cha[counter] = HTML.charAt(i);
                        counter++;
                    }
                    Writers.add(new String(cha).trim());

                    char[] ch = new char[300];
                    counter = 0;
                    for (; counter <= 1; i++) {
                        if (HTML.charAt(i) == '>')
                            counter++;                 //looking where writer #3 name starts
                        if (HTML.charAt(i) == '\n') {
                            EOL = true;
                            break;
                        }
                    }
                    counter = 0;
                    if (EOL == false) {
                        for (; HTML.charAt(i) != '<'; i++) {
                            ch[counter] = HTML.charAt(i);
                            counter++;
                        }
                        if (ch[0] != '|')
                            Writers.add(new String(ch).trim());
                    }
                }
            } else //send unavailable to frontend
            {
                //Writer = "Unavailable";
            }

        } catch (Exception e) {
            //Writer = "Unavailable";
        }

            try {

                if (HTML.contains("\"ratingValue\":")) {
                    temp = HTML.indexOf("\"ratingValue\":");
                    counter = 0;
                    char[] c = new char[300];
                    for (i = temp + 16; i < temp + 16 + 3; i++) {
                        c[counter] = HTML.charAt(i);
                        counter++;
                    }
                    IMDb_rating = new String(c).trim();
                } else //send unavailable to frontend
                {
                    IMDb_rating = "Unavailable";
                }

            } catch (Exception e) {
                IMDb_rating = "Unavailable";
            }


            try {

                if (HTML.contains("<title>")) {
                    temp = HTML.indexOf("property=\"og:title\" content=");
                    counter = 0;
                    char[] c = new char[300];
                    for (i = temp + 29; HTML.charAt(i) != '(' && (HTML.charAt(i + 1) != '1' || HTML.charAt(i + 1) != '2') && HTML.charAt(i + 4) != ')'; i++) {          //checks if a year is in the brackets
                        c[counter] = HTML.charAt(i);
                        counter++;
                    }
                    title = new String(c).trim();
                    char[] ch = new char[100];
                    ch[0] = HTML.charAt(i + 1);
                    ch[1] = HTML.charAt(i + 2);
                    ch[2] = HTML.charAt(i + 3);
                    ch[3] = HTML.charAt(i + 4);
                    year = new String(ch).trim();
                } else //send unavailable to frontend
                {
                    title = "Unavailable";
                    year = "Unavailable";
                }

            } catch (Exception e) {
                title = "Unavailable";
                year = "Unavailable";
            }


            try {

                if (HTML.contains("Poster\" src=\"")) {
                    temp = HTML.indexOf("Poster\" src=\"");
                    counter = 0;
                    char[] c = new char[300];
                    for (i = temp + 13; HTML.charAt(i) != '\"'; i++) {
                        c[counter] = HTML.charAt(i);
                        counter++;
                    }
                    poster_url = new String(c).trim();
                } else //send unavailable to frontend
                {
                    poster_url = "Unavailable";
                }

            } catch (Exception e) {
                poster_url = "Unavailable";
            }


            //id
            if (!link.equals(null)) {
                char[] c = new char[100];
                counter = 0;
                for (i = 27; link.charAt(i) != '/'; i++) {
                    c[counter] = link.charAt(i);
                    counter++;
                }
                id = new String(c).trim();
            }
            else id = null;




            try {

                if (HTML.contains("<h4 class=\"inline\">Stars:</h4>") || HTML.contains("<h4 class=\"inline\">Star:</h4>")) {
                    if (HTML.contains("<h4 class=\"inline\">Stars:</h4>")) {
                        temp = HTML.indexOf("<h4 class=\"inline\">Stars:</h4>");
                    } else temp = HTML.indexOf("<h4 class=\"inline\">Star:</h4>");
                    counter = 0;
                    char[] c = new char[300];
                    for (i = temp; counter <= 2; i++) {
                        if (HTML.charAt(i) == '>') counter++;                 //looking where actor #1 name starts
                    }
                    counter = 0;
                    for (; HTML.charAt(i) != '<'; i++) {
                        c[counter] = HTML.charAt(i);
                        counter++;
                    }
                    Actors.add(new String(c).trim());

                    char[] cha = new char[300];
                    counter = 0;
                    for (; counter <= 1; i++) {
                        if (HTML.charAt(i) == '>') counter++;                 //looking where actor #2 name starts
                    }
                    counter = 0;
                    for (; HTML.charAt(i) != '<'; i++) {
                        cha[counter] = HTML.charAt(i);
                        counter++;
                    }
                    Actors.add(new String(cha).trim());

                    char[] ch = new char[300];
                    counter = 0;
                    for (; counter <= 1; i++) {
                        if (HTML.charAt(i) == '>') counter++;                 //looking where actor #3 name starts
                    }
                    counter = 0;
                    for (; HTML.charAt(i) != '<'; i++) {
                        ch[counter] = HTML.charAt(i);
                        counter++;
                    }
                    Actors.add(new String(ch).trim());
                    //actors = actor1 + ", " + actor2 + ", " + actor3;
                } else //send unavailable to frontend
                {
                    //actors = "Unavailable";
                }

            } catch (Exception e) {
                //actor1 = "Unavailable";
                //actors = "Unavailable";
            }







            try {

                if (HTML.contains("\"genre\": [")) {
                    temp = HTML.indexOf("\"genre\": [");
                    int j;
                    for (i = temp + 15; HTML.charAt(i) != ']'; i += (j - i)) {
                        char[] c = new char[300];
                        counter = 0;
                        for (j = i+1; HTML.charAt(j) != '\"'; j++) {
                            c[counter] = HTML.charAt(j);                //the genre will be quoted
                            counter++;
                        }
                        String category = new String(c).trim();
                        Categories.add(category);
                        do {
                            j++;               //wait for the start of another quote or the end in form of ]
                        } while (HTML.charAt(j) != '\"' && HTML.charAt(j) != ']');
                        if (HTML.charAt(j) == ']') break;
                    }
                } else Categories.add("Unavailable");

            } catch (Exception e) {
                Categories.add("Unavailable");
            }




            try {

                if (HTML.contains("<h4 class=\"inline\">Language:</h4>")) {
                    temp = HTML.indexOf("<h4 class=\"inline\">Language:</h4>") + 34;
                    i = temp;
                    int voidCounter = 3;
                    for (; ; ) {
                        counter = 0;
                        char[] c = new char[500];
                        for (; voidCounter < 4 && HTML.charAt(i) != '\n'; i++) {
                            if (HTML.charAt(i) == '>') voidCounter++;
                        }
                        if (HTML.charAt(i) == '\n') break;
                        for (; HTML.charAt(i) != '<'; i++) {
                            c[counter] = HTML.charAt(i);
                            counter++;
                        }
                        Languages.add(new String(c).trim());
                        voidCounter = 0;
                    }
                } else //send unavailable to frontend
                {
                    Languages.add("Unavailable");
                }

            } catch (Exception e) {
                Languages.add("Unavailable");
            }






            try {

                if (HTML.contains("<h4 class=\"inline\">Country:</h4>")) {
                    temp = HTML.indexOf("<h4 class=\"inline\">Country:</h4>") + 33;
                    i = temp;
                    int voidCounter = 3;
                    for (; ; ) {
                        counter = 0;
                        char[] c = new char[500];
                        for (; voidCounter < 4 && HTML.charAt(i) != '\n'; i++) {
                            if (HTML.charAt(i) == '>') voidCounter++;
                        }
                        if (HTML.charAt(i) == '\n') break;
                        for (; HTML.charAt(i) != '<'; i++) {
                            c[counter] = HTML.charAt(i);
                            counter++;
                        }
                        Countries.add(new String(c).trim());
                        voidCounter = 0;
                    }
                } else //send unavailable to frontend
                {
                    Countries.add("Unavailable");
                }

            } catch (Exception e) {
                Countries.add("Unavailable");
            }








            try {

                if (HTML.contains("\"duration\":")) {
                    temp = HTML.indexOf("\"duration\":");
                        counter = 0;
                        char[] c = new char[100];
                        for (i = temp + 13; HTML.charAt(i) != ',' && HTML.charAt(i) != '\n'; i++) {
                            c[counter] = HTML.charAt(i);
                            counter++;
                        }
                        String s = new String(c).trim();
                        char[] ch = new char[100];
                        counter = 0;
                        for (int j = 2; j < s.length() - 1; j++) {
                            ch[counter] = c[j];
                            counter++;
                        }
                    s = new String(ch).trim();
                    duration = s;
                    }
                else //send unavailable to frontend
                {
                    duration = "Unavailable";
                }

            } catch (Exception e) {
                duration = "Unavailable";
            }

















            System.out.println(Directors);
            System.out.println(Writers);
            System.out.println(IMDb_rating);
            System.out.println(title);
            System.out.println(year);
            System.out.println(poster_url);
            System.out.println(id);
            System.out.println(Actors);
            System.out.println(Categories);
            System.out.println(Languages);
            System.out.println(Countries);
            System.out.println(duration);
            //System.out.println(HTML);
        } catch (IOException e) {        //if an HTTP/connection error occurs, handle JauntException.
            System.err.println(e);
        }
    }


}
