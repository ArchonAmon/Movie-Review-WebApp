package com.example.demo.service;

import com.example.demo.domain.Country;

import java.util.Optional;

public interface CountryService {

    Country createCountry(Country country);

    Country fetchCountry(long id);

    Optional<Country> findByCountryId(long id);

    Optional<Country> findByCountryName(String name);

}
