package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class HasCat implements Serializable {

    @Column
    private Long movieIdCat;

    @Column
    private Long categoryIdCat;

    public HasCat() {
    }

    public HasCat(long movieIdCat, long categoryIdCat) {
        this.movieIdCat = movieIdCat;
        this.categoryIdCat = categoryIdCat;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HasCat hasCat = (HasCat) o;
        return movieIdCat.equals(hasCat.movieIdCat) &&
                categoryIdCat.equals(hasCat.categoryIdCat);
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieIdCat, categoryIdCat);
    }

    public Long getMovieIdCat() {
        return movieIdCat;
    }

    public void setMovieIdCat(Long movieIdCat) {
        this.movieIdCat = movieIdCat;
    }

    public Long getCategoryIdCat() {
        return categoryIdCat;
    }

    public void setCategoryIdCat(Long categoryIdCat) {
        this.categoryIdCat = categoryIdCat;
    }
}
