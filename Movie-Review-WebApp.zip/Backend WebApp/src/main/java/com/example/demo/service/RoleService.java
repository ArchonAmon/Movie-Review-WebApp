package com.example.demo.service;

import com.example.demo.domain.Role;

import java.util.Optional;

public interface RoleService {

    Role createRole(Role role);

    Role fetchRole(long id);

    Optional<Role> findByRoleId(long id);

    Optional<Role> findByRoleName(String roleName);

    Role updateRole(Role role);

    Role deleteRole(long roleId);

}
