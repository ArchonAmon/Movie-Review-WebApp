package com.example.demo.service;

import com.example.demo.domain.Person;

import java.util.Optional;

public interface PersonService {

    Person createPerson(Person person);

    Person fetchPerson(long id);

    Optional<Person> findByPersonId(long id);

    Person updatePerson(Person person);

    Person deletePerson(long personId);

}
