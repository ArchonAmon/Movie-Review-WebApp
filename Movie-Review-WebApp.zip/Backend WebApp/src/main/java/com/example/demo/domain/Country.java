package com.example.demo.domain;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
public class Country {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    @Size(max = 50)
    private String countryName;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "country")
    Set<FilmedInCountry> filmedInCountry;


    public Country() {

    }

    public Country(Long id, String countryName) {
        this.id = id;
        this.countryName = countryName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
}
