package com.example.demo.domain;

import javax.persistence.*;

@Entity
public class FilmedInCountry {

    @EmbeddedId
    private FilmedIn id;

    @ManyToOne
    @MapsId ("movieIdCount")
    private Movie movie;

    @ManyToOne
    @MapsId ("countryIdCount")
    private Country country;

    public FilmedInCountry() {

    }

    public FilmedInCountry(FilmedIn id, Movie movie, Country country) {
        this.id = id;
        this.country = country;
        this.movie = movie;
    }

    public FilmedIn getId() {
        return id;
    }

    public void setId(FilmedIn id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
