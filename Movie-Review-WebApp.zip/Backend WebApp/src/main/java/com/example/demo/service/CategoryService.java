package com.example.demo.service;

import com.example.demo.domain.Category;

import java.util.Optional;

public interface CategoryService {

    Category createCategory(Category category);

    Category fetchCategory(long id);

    Optional<Category> findByCategoryId(long id);

    Optional<Category> findByCatName(String name);

}
