package com.example.demo.domain;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
public class Person {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    @Size(max = 150)
    private String personName;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "person")
    Set<WorksOnMovie> worksOnMovie;

    public Person() {

    }

    public Person(Long id, String personName) {
        this.id = id;
        this.personName = personName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }
}
