package com.example.demo.dao;

import com.example.demo.domain.WorksOnMovie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorksOnMovieRepository extends JpaRepository<WorksOnMovie, Long> {

    //int countByMovieIdWorks(long movieIdWorks);

    //int countByPersonIdWorks(long personIdWorks);

    //int countByRoleIdWorks(long roleIdWorks);

    //List<WorksOnMovie> findAllBy(long movieIdWorks);

}
