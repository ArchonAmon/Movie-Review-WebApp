package com.example.demo;

import com.example.demo.dao.*;
import com.example.demo.domain.*;
import com.example.demo.rest.EntityMissingException;
import com.example.demo.rest.RequestDeniedException;
import com.example.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MovieServiceJpa implements MovieService, RoleService, PersonService, LanguageService, CountryService, CategoryService, FilmedOnLanguageService, FilmedInCountryService, HasCategoryService, WorksOnMovieService, RegisteredUserService {

    MovieSiphoner m;
    Movie mo;

    @Autowired
    private MovieRepository movieRepo;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private PersonRepository personRepo;

    @Autowired
    private LanguageRepository languageRepo;

    @Autowired
    private FilmedOnLanguageRepository filmedOnLanguageRepo;

    @Autowired
    private FilmedInCountryRepository filmedInCountryRepo;

    @Autowired
    private CountryRepository countryRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private HasCategoryRepository hasCategoryRepo;

    @Autowired
    private WorksOnMovieRepository worksOnMovieRepo;

    @Autowired
    private RegisteredUserRepository registeredUserRepo;


    @Override
    public List<Movie> listAll(String username) {
        List<Movie> li = movieRepo.findAll();
        List<Movie> li2 = new ArrayList<>();
        for (int i = li.size() - 1; i >= 0; i--) {
            Movie m = li.get(i);
            if (m.getUser().equals(username)) li2.add(m);
        }
        return li2;
    }

    /*@Override
    public List<Movie> listAllByDirector() {
        return movieRepo.findAll().stream().sorted((l1, l2) -> l1.getDirector().compareTo(l2.getDirector())).collect(Collectors.toList());
    }*/

    @Override
    public List<Movie> listForUserSearch(String name, String username) {
        List<Movie> m = movieRepo.findAll().stream().filter(l -> l.getName().contains(name)).sorted((l1, l2) -> l1.getName().compareTo(l2.getName())).collect(Collectors.toList());
        List<Movie> tmp =  new ArrayList<>();
        for (Movie mov : m) {
            if (mov.getUser().equals(username)) tmp.add(mov);
        }
        return tmp;
    }

    @Override
    public Movie createMovie(Movie movie) {
        Assert.notNull(movie, "Movie object must be given");
       // Check link and username here if any method except createMovieTemplate is using this method
        // or check link and username at those other methods
        return movieRepo.save(movie);
    }

    @Override
    public String createMovieTemplate(String link, String username) {
        //if (movieRepo.countByLink(link) > 0) throw new RequestDeniedException("Movie already added");
        for(Movie m : movieRepo.findAll()) {
            if(m.getUser().equals(username) && m.getLink().equals(link)) throw new RequestDeniedException("Movie already added");
        }
        m = new MovieSiphoner(link);
        mo = new Movie();
        System.out.println(m);
        mo.setName(m.title);
        //mo.setActors(m.actors);
        //mo.setWriter(m.Writer);
        //mo.setDirector(m.Director);
        mo.setIMDb_rating(m.IMDb_rating.equals("Unavailable")?0:Double.parseDouble(m.IMDb_rating));
        mo.setPoster_url(m.poster_url);
        mo.setYear(m.year.equals("Unavailable")?1000:Integer.parseInt(m.year));
        mo.setLink(link);
        mo.setDuration(m.duration);
        mo.setDateViewed(Calendar.getInstance().getTime());
        mo.setUser(username);
        Movie newMovie = createMovie(mo);
        /*
        long movieId = -1;
        for (Movie m : movieRepo.findAll()) {
            if (m.getLink() == link) {
                movieId = m.getId();
                break;
            }
        }
         */
        if(!m.Languages.isEmpty()) {
            for (String s : m.Languages) {
                if (languageRepo.countByLangName(s) <= 0) {
                    Language lan = new Language();
                    lan.setLangName(s);
                    createLanguage(lan);
                }
                //get language with name s and take place it into filmedOn with the movie m
                for (Language l : languageRepo.findAll()) {
                    if (l.getLangName().equals(s)) {
                        FilmedOn f = new FilmedOn(l.getId(), newMovie.getId());
                        createFilmedOnLanguage(new FilmedOnLanguage(f, newMovie, l));
                        break;
                    }
                }

            }
        }



        if(!m.Countries.isEmpty()) {
            for (String s : m.Countries) {
                if (countryRepo.countByCountryName(s) <= 0) {
                    Country c = new Country();
                    c.setCountryName(s);
                    createCountry(c);
                }
                //get language with name s and take place it into filmedOn with the movie m
                for (Country l : countryRepo.findAll()) {
                    if (l.getCountryName().equals(s)) {
                        FilmedIn f = new FilmedIn(l.getId(), newMovie.getId());
                        createFilmedInCountry(new FilmedInCountry(f, newMovie, l));
                        break;
                    }
                }

            }
        }




        if(!m.Categories.isEmpty()) {
            for (String s : m.Categories) {
                if (categoryRepo.countByCatName(s) <= 0) {
                    Category c = new Category();
                    c.setCatName(s);
                    createCategory(c);
                }
                //get language with name s and take place it into filmedOn with the movie m
                for (Category l : categoryRepo.findAll()) {
                    if (l.getCatName().equals(s)) {
                        HasCat f = new HasCat(l.getId(), newMovie.getId());
                        createHasCategory(new HasCategory(f, newMovie, l));
                        break;
                    }
                }

            }
        }





        if(!m.Directors.isEmpty()) {
            for (String s : m.Directors) {
                if (personRepo.countByPersonName(s) <= 0) {
                    Person c = new Person();
                    c.setPersonName(s);
                    createPerson(c);
                }
                //get language with name s and take place it into filmedOn with the movie m
                Role directorRole = null;
                for (Person l : personRepo.findAll()) {
                    if (l.getPersonName().equals(s)) {
                        if (roleRepo.countByRoleName("Director") > 0) {             //if Director exists
                            for (Role r : roleRepo.findAll()) {
                                if (r.getRoleName().equals("Director")) {
                                    directorRole = r;
                                    break;
                                }
                            }
                        }
                        else {
                            Role r = new Role();
                            r.setRoleName("Director");
                            createRole(r);
                            for (Role t : roleRepo.findAll()) {
                                if (t.getRoleName().equals("Director")) {
                                    directorRole = t;
                                    break;
                                }
                            }
                        }
                        WorksOn f = new WorksOn(l.getId(), newMovie.getId(), directorRole.getId());
                        createWorksOnMovie(new WorksOnMovie(f, newMovie, l, directorRole));
                        break;
                    }
                }

            }
        }






        if(!m.Writers.isEmpty()) {
            for (String s : m.Writers) {
                if (personRepo.countByPersonName(s) <= 0) {
                    Person c = new Person();
                    c.setPersonName(s);
                    createPerson(c);
                }
                //get language with name s and take place it into filmedOn with the movie m
                Role writerRole = null;
                for (Person l : personRepo.findAll()) {
                    if (l.getPersonName().equals(s)) {
                        if (roleRepo.countByRoleName("Writer") > 0) {             //if Director exists
                            for (Role r : roleRepo.findAll()) {
                                if (r.getRoleName().equals("Writer")) {
                                    writerRole = r;
                                    break;
                                }
                            }
                        }
                        else {
                            Role r = new Role();
                            r.setRoleName("Writer");
                            createRole(r);
                            for (Role t : roleRepo.findAll()) {
                                if (t.getRoleName().equals("Writer")) {
                                    writerRole = t;
                                    break;
                                }
                            }
                        }
                        WorksOn f = new WorksOn(l.getId(), newMovie.getId(), writerRole.getId());
                        createWorksOnMovie(new WorksOnMovie(f, newMovie, l, writerRole));
                        break;
                    }
                }

            }
        }









        if(!m.Actors.isEmpty()) {
            for (String s : m.Actors) {
                if (personRepo.countByPersonName(s) <= 0) {
                    Person c = new Person();
                    c.setPersonName(s);
                    createPerson(c);
                }
                //get language with name s and take place it into filmedOn with the movie m
                Role actorRole = null;
                for (Person l : personRepo.findAll()) {
                    if (l.getPersonName().equals(s)) {
                        if (roleRepo.countByRoleName("Actor") > 0) {             //if Director exists
                            for (Role r : roleRepo.findAll()) {
                                if (r.getRoleName().equals("Actor")) {
                                    actorRole = r;
                                    break;
                                }
                            }
                        }
                        else {
                            Role r = new Role();
                            r.setRoleName("Actor");
                            createRole(r);
                            for (Role t : roleRepo.findAll()) {
                                if (t.getRoleName().equals("Actor")) {
                                    actorRole = t;
                                    break;
                                }
                            }
                        }
                        WorksOn f = new WorksOn(l.getId(), newMovie.getId(), actorRole.getId());
                        createWorksOnMovie(new WorksOnMovie(f, newMovie, l, actorRole));
                        break;
                    }
                }

            }
        }
        //mo.setUserId(userId);
        //mo.setId( + 1); also if there aren't any movies in the db then make the id 1
        //find the biggest id in the database and add 1 to it and this is the new id
        return mo.toString() + " added successfully";
    }

    @Override
    public Movie fetch(long id, String username) {
        Movie m = findById(id).orElseThrow(
                () -> new EntityMissingException(Movie.class, id)
        );
        if (m.getUser().equals(username)) return m;
        else return null;
    }

    @Override
    public Optional<Movie> findById(long id) {
       return movieRepo.findById(id);
    }

    @Override
    public Movie updateMovie(Movie movie, String username) {
        Long movieId = movie.getId();
        if (!movieRepo.existsById(movieId))
            throw new EntityMissingException(Movie.class, movieId);
        if (movie.getUser().equals(username))
        return movieRepo.save(movie);
        else return null;
    }

    @Override
    public Movie deleteMovie(long movieId, String username) {
        Movie movie = fetch(movieId, username);
        if (movie != null) {
            movieRepo.delete(movie);
            return movie;
        }
        return null;
    }

    @Override
    public List<Movie> listAllByTitle(String username) {
         List<Movie> m = movieRepo.findAll().stream().sorted((l1, l2) -> l1.getName().compareTo(l2.getName())).collect(Collectors.toList());
         List<Movie> tmp =  new ArrayList<>();
         for (Movie mov : m) {
            if (mov.getUser().equals(username)) tmp.add(mov);
         }
         return tmp;
    }

    /*@Override
    public List<Movie> listAllByLeadActor() {
        return movieRepo.findAll().stream().sorted((l1, l2) -> l1.getActor1().compareTo(l2.getActor1())).collect(Collectors.toList());
    }*/

    @Override
    public List<Movie> listAllByIMDbRating(String username) {
        List<Movie> li = movieRepo.findAll().stream().sorted((l1, l2) -> new Double(l1.getIMDb_rating()).compareTo(l2.getIMDb_rating())).collect(Collectors.toList());
        List<Movie> li2 = new ArrayList<>();
        for (int i = li.size() - 1; i >= 0; i--) {
            Movie m = li.get(i);
            if (m.getUser().equals(username)) li2.add(m);
        }
        return li2;
    }

    @Override
    public List<Movie> listAllMyRating(String username) {
        List<Movie> li = movieRepo.findAll().stream().sorted((l1, l2) -> new Integer(l1.getMyRating()).compareTo(l2.getMyRating())).collect(Collectors.toList());
        List<Movie> li2 = new ArrayList<>();
        for (int i = li.size() - 1; i >= 0; i--) {
            Movie m = li.get(i);
            if (m.getUser().equals(username)) li2.add(m);
        }
        return li2;
    }

    /*@Override
    public List<Movie> listAllByWriter() {
        return movieRepo.findAll().stream().sorted((l1, l2) -> l1.getWriter().compareTo(l2.getWriter())).collect(Collectors.toList());
    }*/

    @Override
    public List<Movie> listAllByYear(String username) {
        List<Movie> m = movieRepo.findAll().stream().sorted((l1, l2) -> new Integer(l1.getYear()).compareTo(l2.getYear())).collect(Collectors.toList());
        List<Movie> tmp =  new ArrayList<>();
        for (Movie mov : m) {
            if (mov.getUser().equals(username)) tmp.add(mov);
        }
        return tmp;
    }

    @Override
    public List<Movie> listAllByDuration(String username) {
        List<Movie> li = movieRepo.findAll().stream().sorted((l1, l2) -> new Integer(l1.getDuration()).compareTo(l2.getDuration())).collect(Collectors.toList());
        List<Movie> li2 = new ArrayList<>();
        for (int i = li.size() - 1; i >= 0; i--) {
            Movie m = li.get(i);
            if (m.getUser().equals(username)) li2.add(m);
        }
        return li2;
    }












    @Override
    public Language createLanguage(Language language) {
        Assert.notNull(language, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (languageRepo.countByLangName(language.getLangName()) > 0)
            throw new RequestDeniedException(
                    "Language with name " + language.getLangName() + " already exists"
            );
        return languageRepo.save(language);
    }

    @Override
    public Language fetchLang(long id) {
        return findByLangId(id).orElseThrow(
                () -> new EntityMissingException(Language.class, id)
        );
    }

    @Override
    public Optional<Language> findByLangId(long id) {
        return languageRepo.findById(id);
    }

    @Override
    public Optional<Language> findByLangName(String name) {
        return Optional.empty();                    //to be changed or deleted
    }










    @Override
    public FilmedOnLanguage createFilmedOnLanguage(FilmedOnLanguage filmedOnLanguage) {
        Assert.notNull(filmedOnLanguage, "FilmedOn object must be given");
        return filmedOnLanguageRepo.save(filmedOnLanguage);
    }

    @Override
    public Optional<FilmedOnLanguage> findByMovieIdLang(long movieIdLang) {
        return Optional.empty();
    }

    @Override
    public Optional<FilmedOnLanguage> findByLanguageIdLang(long languageIdLang) {
        return Optional.empty();
    }


    @Override
    public FilmedInCountry createFilmedInCountry(FilmedInCountry filmedInCountry) {
        Assert.notNull(filmedInCountry, "FilmedIn object must be given");
        return filmedInCountryRepo.save(filmedInCountry);
    }

    @Override
    public Optional<FilmedInCountry> findByMovieIdCount(long movieIdCount) {
        return Optional.empty();
    }

    @Override
    public Optional<FilmedInCountry> findByLanguageIdCount(long languageIdCount) {
        return Optional.empty();
    }


    @Override
    public Country createCountry(Country country) {
        Assert.notNull(country, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (countryRepo.countByCountryName(country.getCountryName()) > 0)
            throw new RequestDeniedException(
                    "Country with name " + country.getCountryName() + " already exists"
            );
        return countryRepo.save(country);
    }

    @Override
    public Country fetchCountry(long id) {
        return findByCountryId(id).orElseThrow(
                () -> new EntityMissingException(Country.class, id)
        );
    }

    @Override
    public Optional<Country> findByCountryId(long id) {
        return countryRepo.findById(id);
    }

    @Override
    public Optional<Country> findByCountryName(String name) {
        return Optional.empty();
    }








    @Override
    public Category createCategory(Category category) {
        Assert.notNull(category, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (categoryRepo.countByCatName(category.getCatName()) > 0)
            throw new RequestDeniedException(
                    "Category with name " + category.getCatName() + " already exists"
            );
        return categoryRepo.save(category);
    }

    @Override
    public Category fetchCategory(long id) {
        return findByCategoryId(id).orElseThrow(
                () -> new EntityMissingException(Category.class, id)
        );
    }

    @Override
    public Optional<Category> findByCategoryId(long id) {
        return categoryRepo.findById(id);
    }

    @Override
    public Optional<Category> findByCatName(String name) {
        return Optional.empty();
    }








    @Override
    public HasCategory createHasCategory(HasCategory hasCategory) {
        Assert.notNull(hasCategory, "HasCategory object must be given");
        return hasCategoryRepo.save(hasCategory);
    }

    @Override
    public Optional<HasCategory> findByMovieIdCat(long movieIdCat) {
        return Optional.empty();
    }

    @Override
    public Optional<HasCategory> findByCategoryIdCat(long categoryIdCat) {
        return Optional.empty();
    }


    @Override
    public Person createPerson(Person person) {
        Assert.notNull(person, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (personRepo.countByPersonName(person.getPersonName()) > 0)
            throw new RequestDeniedException(
                    "Person with name " + person.getPersonName() + " already exists"
            );
        return personRepo.save(person);
    }

    @Override
    public Person fetchPerson(long id) {
        return null;
    }

    @Override
    public Optional<Person> findByPersonId(long id) {
        return Optional.empty();
    }

    @Override
    public Person updatePerson(Person person) {
        return null;
    }

    @Override
    public Person deletePerson(long personId) {
        return null;
    }













    @Override
    public Role createRole(Role role) {
        Assert.notNull(role, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (roleRepo.countByRoleName(role.getRoleName()) > 0)
            throw new RequestDeniedException(
                    "Role with name " + role.getRoleName() + " already exists"
            );
        return roleRepo.save(role);
    }

    @Override
    public Role fetchRole(long id) {
        return null;
    }

    @Override
    public Optional<Role> findByRoleId(long id) {
        return Optional.empty();
    }

    @Override
    public Optional<Role> findByRoleName(String roleName) {
        return Optional.empty();
    }

    @Override
    public Role updateRole(Role role) {
        return null;
    }

    @Override
    public Role deleteRole(long roleId) {
        return null;
    }













    @Override
    public WorksOnMovie createWorksOnMovie(WorksOnMovie worksOnMovie) {
        Assert.notNull(worksOnMovie, "HasCategory object must be given");
        return worksOnMovieRepo.save(worksOnMovie);
    }

    @Override
    public Optional<WorksOnMovie> findByMovieIdWorks(long movieIdWorks) {
        return Optional.empty();
    }

    @Override
    public Optional<WorksOnMovie> findByRoleIdWorks(long roleIdWorks) {
        return Optional.empty();
    }

    @Override
    public Optional<WorksOnMovie> findByPersonIdWorks(long personIdWorks) {
        return Optional.empty();
    }










    @Override
    public RegisteredUser createRegisteredUser(RegisteredUser registeredUser) {
        Assert.notNull(registeredUser, "Language object must be given");
        // Assert.isNull(movie.getId(), "Movie ID must be null, not" + movie.getId());
        if (registeredUserRepo.countByUsername(registeredUser.getUsername()) > 0)
            throw new RequestDeniedException(
                    "Registered User with name " + registeredUser.getUsername() + " already exists"
            );
        return registeredUserRepo.save(registeredUser);
    }

    @Override
    public RegisteredUser fetchRegisteredUser(long id) {
        return null;
    }

    @Override
    public Optional<RegisteredUser> findByRegisteredUserId(long id) {
        return Optional.empty();
    }

    @Override
    public RegisteredUser updateRegisteredUser(RegisteredUser person) {
        return null;
    }

    @Override
    public RegisteredUser deleteRegisteredUser(long registeredUserId) {
        return null;
    }

    @Override
    public List<RegisteredUser> listAllUsers() {
        return registeredUserRepo.findAll();
    }
}