package com.example.demo.service;

        import com.example.demo.domain.Language;

        import java.util.Optional;

public interface LanguageService {

    Language createLanguage(Language language);

    Language fetchLang(long id);

    Optional<Language> findByLangId(long id);

    Optional<Language> findByLangName(String name);

}
