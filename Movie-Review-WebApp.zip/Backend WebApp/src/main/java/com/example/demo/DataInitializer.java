package com.example.demo;

import com.example.demo.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Example component used to insert some test movies at application startup.
 */
@Component
public class DataInitializer {
    @Autowired
    private MovieService movieService;
    public MovieServiceJpa jpa = new MovieServiceJpa();


    @Value("Men in black")
    private String testNames;


    @EventListener
    public void appReady(ApplicationReadyEvent event) {
            //movieService.createMovie(makeMovie(testNames, 1));
            //jpa.createMovieTemplate("https://www.imdb.com/title/tt7286456/?ref_=tt_sims_tti");
    }

    /*private Movie makeMovie(String prefix, int i) {
        Movie movie = new Movie();
        movie.setId(Integer.toUnsignedLong(i));
        movie.setName(prefix);
        movie.setPoster_url("https://m.media-amazon.com/images/M/MV5BOTlhYTVkMDktYzIyNC00NzlkLTlmN2ItOGEyMWQ4OTA2NDdmXkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_SY1000_CR0,0,666,1000_AL_.jpg");
        return movie;
    }*/
}
