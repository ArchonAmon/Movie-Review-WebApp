package com.example.demo.service;

import com.example.demo.domain.WorksOnMovie;

import java.util.Optional;

public interface WorksOnMovieService {

    WorksOnMovie createWorksOnMovie(WorksOnMovie worksOnMovie);

    Optional<WorksOnMovie> findByMovieIdWorks(long movieIdWorks);

    Optional<WorksOnMovie> findByRoleIdWorks(long roleIdWorks);

    Optional<WorksOnMovie> findByPersonIdWorks(long personIdWorks);

    //WorksOnMovie deleteWorksOnMovie(long movieIdWorks, long personIdWorks, long roleIdWorks);    //newly added



}
