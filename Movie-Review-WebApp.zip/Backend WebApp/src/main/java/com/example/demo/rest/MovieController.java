package com.example.demo.rest;

import com.example.demo.*;
import com.example.demo.dao.*;
import com.example.demo.domain.*;
import com.example.demo.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@RestController
public class MovieController {

    @Autowired
    private MovieService movieService;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private PersonRepository personRepo;

    @Autowired
    private LanguageRepository languageRepo;

    @Autowired
    private FilmedOnLanguageRepository filmedOnLanguageRepo;

    @Autowired
    private FilmedInCountryRepository filmedInCountryRepo;

    @Autowired
    private CountryRepository countryRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private HasCategoryRepository hasCategoryRepo;

    @Autowired
    private WorksOnMovieRepository worksOnMovieRepo;

    @Autowired
    private MovieServiceJpa movieServiceJpa;

    @Autowired
    private RegisteredUserRepository registeredUserRepo;

    @Autowired
    private PasswordEncoder pac;

/*
    @GetMapping("/movies")
    @Secured("ROLE_USER")
    public List<Movie> listMovies(@AuthenticationPrincipal User u) {
        ArrayList<Movie> mov = new ArrayList<>();
        for (Movie m : movieService.listAll(u.getUsername())) {
            mov.add(new Movie(m.getId(), m.getName(), m.getPoster_url(), m.getLink(), m.getIMDb_rating(), m.getMyRating(), m.getYear(), m.getReview(), m.getDateViewed(), m.getDuration(), m.isMovieAdded(), u.getUsername()));
        }

        return mov;
    }*/

    @GetMapping("/movies")
    @Secured("ROLE_USER")
    public MovieAndStatistics listStatistics(@AuthenticationPrincipal User u) {
        ArrayList<Movie> mov = new ArrayList<>();
        long dirId = -1;
        long wriId = -1;
        long actId = -1;
        for (Role r : roleRepo.findAll()) {
            if (r.getRoleName().equals("Director")) dirId = r.getId();
            else if (r.getRoleName().equals("Writer")) wriId = r.getId();
            else if (r.getRoleName().equals("Actor")) actId = r.getId();
        }

        String bestActor = "Unknown";
        String bestActorMy = "Unknown";
        String bestDirector = "Unknown";
        String bestDirectorMy = "Unknown";
        String bestWriter = "Unknown";
        String bestWriterMy = "Unknown";
        String worstActor = "Unknown";
        String worstActorMy = "Unknown";
        String worstDirector = "Unknown";
        String worstDirectorMy = "Unknown";
        String worstWriter = "Unknown";
        String worstWriterMy = "Unknown";
        for (Movie m : movieService.listAll(u.getUsername())) {
            mov.add(new Movie(m.getId(), m.getName(), m.getPoster_url(), m.getLink(), m.getIMDb_rating(), m.getMyRating(), m.getYear(), m.getReview(), m.getDateViewed(), m.getDuration(), m.isMovieAdded(), u.getUsername()));
        }


        double actorAvg = 0;
        double actorAvgMy = 0;
        double actorAvgLow = 11;
        double actorAvgLowMy = 11;


        double directorAvg = 0;
        double directorAvgMy = 0;
        double directorAvgLow = 11;
        double directorAvgLowMy = 11;


        double writerAvg = 0;
        double writerAvgMy = 0;
        double writerAvgLow = 11;
        double writerAvgLowMy = 11;

        for (Person p : personRepo.findAll()) {
            int numberOfMoviesActor = 0;
            double wholeActorRating = 0;
            double wholeActorRatingMy = 0;
            int numberOfMoviesDirector = 0;
            double wholeDirectorRating = 0;
            double wholeDirectorRatingMy = 0;
            int numberOfMoviesWriter = 0;
            double wholeWriterRating = 0;
            double wholeWriterRatingMy = 0;


            for (WorksOnMovie w : worksOnMovieRepo.findAll()) {

                for (Movie m : movieService.listAll(u.getUsername())) {

                    if (w.getId().getRoleIdWorks() == actId && w.getId().getMovieIdWorks().equals(m.getId()) && w.getId().getPersonIdWorks().equals(p.getId())) {
                        numberOfMoviesActor++;
                        wholeActorRating += m.getIMDb_rating();
                        wholeActorRatingMy += m.getMyRating();

                    }
                    else if (w.getId().getRoleIdWorks() == dirId && w.getId().getMovieIdWorks().equals(m.getId()) && w.getId().getPersonIdWorks().equals(p.getId())) {
                        numberOfMoviesDirector++;
                        wholeDirectorRating += m.getIMDb_rating();
                        wholeDirectorRatingMy += m.getMyRating();
                    }
                    else if (w.getId().getRoleIdWorks() == wriId && w.getId().getMovieIdWorks().equals(m.getId()) && w.getId().getPersonIdWorks().equals(p.getId())) {
                        numberOfMoviesWriter++;
                        wholeWriterRating += m.getIMDb_rating();
                        wholeWriterRatingMy += m.getMyRating();
                    }

                }
            }
            if (wholeActorRating/(double)numberOfMoviesActor > actorAvg) {
                actorAvg = wholeActorRating/(double)numberOfMoviesActor;
                bestActor = p.getPersonName() + ", " + actorAvg;
            }
            if (wholeActorRatingMy/(double)numberOfMoviesActor > actorAvgMy) {
                actorAvgMy = wholeActorRatingMy/(double)numberOfMoviesActor;
                bestActorMy = p.getPersonName() + ", " + actorAvgMy;
            }
            if (wholeActorRating/(double)numberOfMoviesActor < actorAvgLow) {
                actorAvgLow = wholeActorRating/(double)numberOfMoviesActor;
                worstActor = p.getPersonName() + ", " + actorAvgLow;
            }
            if (wholeActorRatingMy/(double)numberOfMoviesActor < actorAvgLowMy) {
                actorAvgLowMy = wholeActorRatingMy/(double)numberOfMoviesActor;
                worstActorMy = p.getPersonName() + ", " + actorAvgLowMy;
            }

            if (wholeDirectorRating/(double)numberOfMoviesDirector > directorAvg) {
                directorAvg = wholeDirectorRating/(double)numberOfMoviesDirector;
                bestDirector = p.getPersonName() + ", " + directorAvg;
            }
            if (wholeDirectorRatingMy/(double)numberOfMoviesDirector > directorAvgMy) {
                directorAvgMy = wholeDirectorRatingMy/(double)numberOfMoviesDirector;
                bestDirectorMy = p.getPersonName() + ", " + directorAvgMy;
            }
            if (wholeDirectorRating/(double)numberOfMoviesDirector < directorAvgLow) {
                directorAvgLow = wholeDirectorRating/(double)numberOfMoviesDirector;
                worstDirector = p.getPersonName() + ", " + directorAvgLow;
            }
            if (wholeDirectorRatingMy/(double)numberOfMoviesDirector < directorAvgLowMy) {
                directorAvgLowMy = wholeDirectorRatingMy/(double)numberOfMoviesDirector;
                worstDirectorMy = p.getPersonName() + ", " + directorAvgLowMy;
            }

            if (wholeWriterRating/(double)numberOfMoviesWriter > writerAvg) {
                writerAvg = wholeWriterRating/(double)numberOfMoviesWriter;
                bestWriter = p.getPersonName() + ", " + writerAvg;
            }
            if (wholeWriterRatingMy/(double)numberOfMoviesWriter > writerAvgMy) {
                writerAvgMy = wholeWriterRatingMy/(double)numberOfMoviesWriter;
                bestWriterMy = p.getPersonName() + ", " + writerAvgMy;
            }
            if (wholeWriterRating/(double)numberOfMoviesWriter < writerAvgLow) {
                writerAvgLow = wholeWriterRating/(double)numberOfMoviesWriter;
                worstWriter = p.getPersonName() + ", " + writerAvgLow;
            }
            if (wholeWriterRatingMy/(double)numberOfMoviesWriter < writerAvgLowMy) {
                writerAvgLowMy = wholeWriterRatingMy/(double)numberOfMoviesWriter;
                worstWriterMy = p.getPersonName() + ", " + writerAvgLowMy;
            }
        }

        String result = String.join(";", bestActor, bestActorMy, bestDirector, bestDirectorMy, bestWriter, bestWriterMy, worstActor, worstActorMy, worstDirector, worstDirectorMy,
                worstWriter, worstWriterMy);

        //calculate the best/worst actor/director etc and then call them with every 
        return new MovieAndStatistics(mov, result);
    }

    @GetMapping("/movies/userSearchResult/{name}")
    @Secured("ROLE_USER")
    public List<Movie> listForUserSearch(@PathVariable String name, @AuthenticationPrincipal User u) {
        String name2 = "";
        for (int i = 0; i < name.split("\\+").length; i++) {
            if (i != 0) {
                name2 += " " + name.split("\\+")[i];
            }
            else name2 += name.split("\\+")[i];
        }
        ArrayList<Movie> movieList = new ArrayList<>();
        ArrayList<Long> movieIdList = new ArrayList<>();
        name2 = name2.toLowerCase();

        for (Person p : personRepo.findAll()) {
            if (p.getPersonName().toLowerCase().equals(name2)) {
                for (WorksOnMovie w : worksOnMovieRepo.findAll()) {
                    if (w.getId().getPersonIdWorks().equals(p.getId())) {
                        movieIdList.add(w.getId().getMovieIdWorks());
                    }
                }
            }
        }

        for (Country p : countryRepo.findAll()) {
            if (p.getCountryName().toLowerCase().equals(name2)) {
                for (FilmedInCountry w : filmedInCountryRepo.findAll()) {
                    if (w.getId().getCountryIdCount().equals(p.getId())) {
                        movieIdList.add(w.getId().getMovieIdCount());
                    }
                }
            }
        }

        for (Language p : languageRepo.findAll()) {
            if (p.getLangName().toLowerCase().equals(name2)) {
                for (FilmedOnLanguage w : filmedOnLanguageRepo.findAll()) {
                    if (w.getId().getLanguageIdLang().equals(p.getId())) {
                        movieIdList.add(w.getId().getMovieIdLang());
                    }
                }
            }
        }

        for (Category p : categoryRepo.findAll()) {
            if (p.getCatName().toLowerCase().equals(name2)) {
                for (HasCategory w : hasCategoryRepo.findAll()) {
                    if (w.getId().getCategoryIdCat().equals(p.getId())) {
                        movieIdList.add(w.getId().getMovieIdCat());
                    }
                }
            }
        }


        for (Movie m : movieService.listAll(u.getUsername())) {
            if (m.getName().toLowerCase().equals(name2) && m.getUser().equals(u.getUsername())) {
                movieList.add(m);
                break;
            }
        }

        for (Long l : movieIdList) {
            Movie m = movieService.fetch(l, u.getUsername());
            if (m != null && !movieList.contains(m))
            movieList.add(m);
        }


        return movieList;
    }

    @GetMapping("/movies/byDateViewed")
    @Secured("ROLE_USER")
    public List<Movie> listMoviesByDateViewed(@AuthenticationPrincipal User u) {
        return movieService.listAll(u.getUsername());
    }

    /*@GetMapping("/byDirector")
    public List<Movie> listMoviesByDirector() {
        return movieService.listAllByDirector();
    }*/

    @GetMapping("/movies/byTitle")
    @Secured("ROLE_USER")
    public List<Movie> listMoviesByTitle(@AuthenticationPrincipal User u) {
        return movieService.listAllByTitle(u.getUsername());
    }

    /*@GetMapping("/byLeadActor")
    public List<Movie> listMoviesByLeadActor() {
        return movieService.listAllByLeadActor();
    }*/

    @GetMapping("/movies/byIMDbRating")
    @Secured("ROLE_USER")
    public List<Movie> listMoviesByIMDbRating(@AuthenticationPrincipal User u) {
        return movieService.listAllByIMDbRating(u.getUsername());
    }

    @GetMapping("/movies/byMyRating")
    @Secured("ROLE_USER")
    public List<Movie> listMoviesByMyRating(@AuthenticationPrincipal User u) {
        return movieService.listAllMyRating(u.getUsername());
    }

    /*@GetMapping("/byWriter")
    public List<Movie> listMoviesByWriter() {
        return movieService.listAllByWriter();
    }*/

    @GetMapping("/movies/byYear")
    @Secured("ROLE_USER")
    public List<Movie> listMoviesByYear(@AuthenticationPrincipal User u) {
        return movieService.listAllByYear(u.getUsername());
    }

    @GetMapping("/movies/byDuration")
    @Secured("ROLE_USER")
    public List<Movie> listAllByDuration(@AuthenticationPrincipal User u) {
        return movieService.listAllByDuration(u.getUsername());
    }

    @PostMapping("/movies")   //create new
    @Secured("ROLE_USER")
    public String createMovieTemplate(@RequestBody String link, @AuthenticationPrincipal User u) {
        return movieService.createMovieTemplate(link, u.getUsername());
    }

    @GetMapping("/movies/{id}")
    @Secured("ROLE_USER")
    public WholeMovie getMovie(@PathVariable ("id") Long id, @AuthenticationPrincipal User u) {
            Movie m = movieService.fetch(id, u.getUsername());
            if (m == null) return null;
                HashSet<Country> countries = new HashSet<>();
                for (FilmedInCountry filmedIn : filmedInCountryRepo.findAll()) {
                    if (m.getId().equals(filmedIn.getId().getMovieIdCount())) {
                        for (Country c : countryRepo.findAll()) {
                            if (c.getId().equals(filmedIn.getId().getCountryIdCount())) countries.add(c);
                        }
                    }
                }


                HashSet<Language> languages = new HashSet<>();
                for (FilmedOnLanguage filmedOn : filmedOnLanguageRepo.findAll()) {
                    if (m.getId().equals(filmedOn.getId().getMovieIdLang())) {
                        for(Language c : languageRepo.findAll()) {
                            if (c.getId().equals(filmedOn.getId().getLanguageIdLang())) languages.add(c);
                        }
                    }
                }

                HashSet<Category> categories = new HashSet<>();
                for (HasCategory hasCategory : hasCategoryRepo.findAll()) {
                    if (m.getId().equals(hasCategory.getId().getMovieIdCat())) {
                        for(Category c : categoryRepo.findAll()) {
                            if (c.getId().equals(hasCategory.getId().getCategoryIdCat())) categories.add(c);
                        }
                    }
                }

                HashSet<Person> directors = new HashSet<>();
                HashSet<Person> writers = new HashSet<>();
                HashSet<Person> actors = new HashSet<>();
                long dirId = -1;
                long wriId = -1;
                long actId = -1;
                for (Role r : roleRepo.findAll()) {
                    if (r.getRoleName().equals("Director")) dirId = r.getId();
                    else if (r.getRoleName().equals("Writer")) wriId = r.getId();
                    else if (r.getRoleName().equals("Actor")) actId = r.getId();
                }
                for (WorksOnMovie worksOnMovie : worksOnMovieRepo.findAll()) {
                    if (m.getId().equals(worksOnMovie.getId().getMovieIdWorks())) {
                        for(Person c : personRepo.findAll()) {
                            if (c.getId().equals(worksOnMovie.getId().getPersonIdWorks()) && worksOnMovie.getId().getRoleIdWorks().equals(dirId)) directors.add(c);
                            else if (c.getId().equals(worksOnMovie.getId().getPersonIdWorks()) && worksOnMovie.getId().getRoleIdWorks().equals(wriId)) writers.add(c);
                            else if (c.getId().equals(worksOnMovie.getId().getPersonIdWorks()) && worksOnMovie.getId().getRoleIdWorks().equals(actId)) actors.add(c);
                        }
                    }
                }
                String country2 = "";
                String language2 = "";
                String categories2 = "";
                String directors2 = "";
                String writers2 = "";
                String actors2 = "";
                for (Country s : countries) {
                    if (!country2.equals(""))
                    country2 += ", " + s.getCountryName();
                    else country2 += s.getCountryName();
                }
                for (Language s : languages) {
                    if (!language2.equals(""))
                        language2 += ", " + s.getLangName();
                    else language2 += s.getLangName();                }
                for (Category s : categories) {
                    if (!categories2.equals(""))
                        categories2 += ", " + s.getCatName();
                    else categories2 += s.getCatName();
                }
                for (Person s : directors) {
                    if (!directors2.equals(""))
                        directors2 += ", " + s.getPersonName();
                    else directors2 += s.getPersonName();
                }
                for (Person s : writers) {
                    if (!writers2.equals(""))
                        writers2 += ", " + s.getPersonName();
                    else writers2 += s.getPersonName();
                }
                for (Person s : actors) {
                    if (!actors2.equals(""))
                        actors2 += ", " + s.getPersonName();
                    else actors2 += s.getPersonName();
                }
                WholeMovie mov = new WholeMovie(m.getId(), m.getName(), m.getPoster_url(), m.getLink(), m.getIMDb_rating(), m.getYear(), m.getReview(), m.getDateViewed(), m.getMyRating(), m.getDuration(), m.isMovieAdded(), country2.trim(), language2.trim(), categories2.trim(), directors2.trim(), writers2.trim(), actors2.trim());
                return mov;
    }

    @PutMapping("/movies/{id}") //update
    @Secured("ROLE_USER")
    public Movie updateMovie(@PathVariable("id") Long id, @RequestBody WholeMovie wholeMovie, @AuthenticationPrincipal User u) {
        if (!wholeMovie.getId().equals(id)) throw new IllegalArgumentException("Movie ID must be preserved");
        Movie m = new Movie(wholeMovie.getId(), wholeMovie.getName(), wholeMovie.getPoster_url(), wholeMovie.getLink(), wholeMovie.getIMDb_rating(), wholeMovie.getMyRating(), wholeMovie.getYear(), wholeMovie.getReview(), wholeMovie.getDateViewed(), wholeMovie.getDuration(), wholeMovie.isMovieAdded(), u.getUsername());

        long dirId = -1;
        long wriId = -1;
        long actId = -1;
        for (Role r : roleRepo.findAll()) {
            if (r.getRoleName().equals("Director")) dirId = r.getId();
            else if (r.getRoleName().equals("Writer")) wriId = r.getId();
            else if (r.getRoleName().equals("Actor")) actId = r.getId();
        }

        if (wholeMovie.getCountries().split(", ").length > 10 && wholeMovie.getCountries().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        for (FilmedInCountry f : filmedInCountryRepo.findAll()) {
            if (f.getId().getMovieIdCount().equals(wholeMovie.getId())) filmedInCountryRepo.delete(f);
        }
        if (wholeMovie.getLanguages().split(", ").length > 10 && wholeMovie.getLanguages().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        for (FilmedOnLanguage f : filmedOnLanguageRepo.findAll()) {
            if (f.getId().getMovieIdLang().equals(wholeMovie.getId())) filmedOnLanguageRepo.delete(f);
        }
        if (wholeMovie.getCategories().split(", ").length > 10 && wholeMovie.getCategories().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        for (HasCategory f : hasCategoryRepo.findAll()) {
            if (f.getId().getMovieIdCat().equals(wholeMovie.getId())) hasCategoryRepo.delete(f);
        }
        if (wholeMovie.getDirectors().split(", ").length > 10 && wholeMovie.getDirectors().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        if (wholeMovie.getWriters().split(", ").length > 10 && wholeMovie.getWriters().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        if (wholeMovie.getActors().split(", ").length > 10 && wholeMovie.getActors().length() > 500) throw new IllegalArgumentException("Only 5 arguments per category allowed");
        for (WorksOnMovie f : worksOnMovieRepo.findAll()) {
            if (f.getId().getMovieIdWorks().equals(wholeMovie.getId())) worksOnMovieRepo.delete(f);
        }



            for (String s : wholeMovie.getCountries().split(", ")) {                //reads countries and updates FilmedInCountry if that country exists, if not then the country is created and then the table is updated
                boolean countryExists = false;
                for (Country c : countryRepo.findAll()) {
                    if (c.getCountryName().toLowerCase().equals(s.toLowerCase())) {
                        countryExists = true;
                        FilmedIn f = new FilmedIn(wholeMovie.getId(), c.getId());
                        movieServiceJpa.createFilmedInCountry(new FilmedInCountry(f, m, c));
                        break;
                    }
                }
                if (countryExists == false) {           //create new country
                    Country c = new Country();
                    c.setCountryName(s);
                    c = movieServiceJpa.createCountry(c);
                //get language with name s and take place it into filmedOn with the movie m
                    FilmedIn f = new FilmedIn(wholeMovie.getId(), c.getId());
                    movieServiceJpa.createFilmedInCountry(new FilmedInCountry(f, m, c));
                }
            }




        for (String s : wholeMovie.getLanguages().split(", ")) {
            boolean languageExists = false;
            for (Language c : languageRepo.findAll()) {
                if (c.getLangName().toLowerCase().equals(s.toLowerCase())) {
                    languageExists = true;
                    FilmedOn f = new FilmedOn(wholeMovie.getId(), c.getId());
                    movieServiceJpa.createFilmedOnLanguage(new FilmedOnLanguage(f, m, c));
                    break;
                }
            }
            if (languageExists == false) {           //create new country
                Language c = new Language();
                c.setLangName(s);
                c = movieServiceJpa.createLanguage(c);
                //get language with name s and take place it into filmedOn with the movie m
                FilmedOn f = new FilmedOn(wholeMovie.getId(), c.getId());
                movieServiceJpa.createFilmedOnLanguage(new FilmedOnLanguage(f, m, c));
            }
        }






        for (String s : wholeMovie.getCategories().split(", ")) {
            boolean categoryExists = false;
            for (Category c : categoryRepo.findAll()) {
                if (c.getCatName().toLowerCase().equals(s.toLowerCase())) {
                    categoryExists = true;
                    HasCat f = new HasCat(wholeMovie.getId(), c.getId());
                    movieServiceJpa.createHasCategory(new HasCategory(f, m, c));
                    break;
                }
            }
            if (categoryExists == false) {           //create new country
                Category c = new Category();
                c.setCatName(s);
                c = movieServiceJpa.createCategory(c);
                //get language with name s and take place it into filmedOn with the movie m
                HasCat f = new HasCat(wholeMovie.getId(), c.getId());
                movieServiceJpa.createHasCategory(new HasCategory(f, m, c));
            }
        }






        for (String s : wholeMovie.getDirectors().split(", ")) {
            boolean personExists = false;
            for (Person c : personRepo.findAll()) {
                if (c.getPersonName().toLowerCase().equals(s.toLowerCase())) {
                    personExists = true;
                    WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), dirId);
                    movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(dirId)));
                    break;
                }
            }
            if (personExists == false) {           //create new country
                Person c = new Person();
                c.setPersonName(s);
                c = movieServiceJpa.createPerson(c);
                //get language with name s and take place it into filmedOn with the movie m
                WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), dirId);
                movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(dirId)));
                break;
            }
        }





        for (String s : wholeMovie.getWriters().split(", ")) {
            boolean personExists = false;
            for (Person c : personRepo.findAll()) {
                if (c.getPersonName().toLowerCase().equals(s.toLowerCase())) {
                    personExists = true;
                    WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), wriId);
                    movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(wriId)));
                    break;
                }
            }
            if (personExists == false) {           //create new country
                Person c = new Person();
                c.setPersonName(s);
                c = movieServiceJpa.createPerson(c);
                //get language with name s and take place it into filmedOn with the movie m
                WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), wriId);
                movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(wriId)));
                break;
            }
        }




        for (String s : wholeMovie.getActors().split(", ")) {
            boolean personExists = false;
            for (Person c : personRepo.findAll()) {
                if (c.getPersonName().toLowerCase().equals(s.toLowerCase())) {
                    personExists = true;
                    WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), actId);
                    movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(actId)));
                    break;
                }
            }
            if (personExists == false) {           //create new country
                Person c = new Person();
                c.setPersonName(s);
                c = movieServiceJpa.createPerson(c);
                //get language with name s and take place it into filmedOn with the movie m
                WorksOn f = new WorksOn(wholeMovie.getId(), c.getId(), actId);
                movieServiceJpa.createWorksOnMovie(new WorksOnMovie(f, m, c, roleRepo.getOne(actId)));
                break;
            }
        }
        if (m.getUser().equals(u.getUsername()))
        return movieService.updateMovie(m, u.getUsername());
        else return null;
    }

    @DeleteMapping("/movies/{id}")
    @Secured("ROLE_USER")
    public Movie deleteMovie(@PathVariable("id") long movieId, @AuthenticationPrincipal User u) {
        return movieService.deleteMovie(movieId, u.getUsername());
    }

    @PostMapping("/register")
    public String createRegisteredUser(@RequestBody RegisteredUser regUs) {
        if (regUs.getUsername().length() < 4) return "Korisničko ime mora imati barem 4 znaka";
        if (regUs.getUsername().length() > 30) return "Koristničko ime ne smije biti dulje od 30 znakova";
        if (regUs.getPassword().length() < 4) return "Lozinka mora imati barem 4 znaka";
        if (regUs.getPassword().length() > 30) return "Lozinka ne smije biti dulja od 30 znakova";
        if (regUs.getEmail().length() < 3 || !regUs.getEmail().contains("@")) return "Kriva email adresa";
        if (regUs.getEmail().length() > 50) return "Email adresa je predugačka";

        for (RegisteredUser r : registeredUserRepo.findAll()) {
            if (r.getUsername().equals(regUs.getUsername())) return "Korisnik već postoji";
            if (r.getEmail().equals(regUs.getEmail())) return "Email adresa se već koristi";
        }

        RegisteredUser reg = new RegisteredUser(regUs.getUsername(), pac.encode(regUs.getPassword()), regUs.getEmail());
        movieServiceJpa.createRegisteredUser(reg);

        for (RegisteredUser r : registeredUserRepo.findAll()) {
            if (r.getUsername().equals(regUs.getUsername())) return "User registered";
        }
        return "Registracija nije uspjela";
    }

}