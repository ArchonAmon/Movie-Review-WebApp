package com.example.demo.dao;

import com.example.demo.domain.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryRepository extends JpaRepository<Country, Long> {           //required for working with the DB

    int countById(long id);

    int countByCountryName(String name);

    //long maxId();

}