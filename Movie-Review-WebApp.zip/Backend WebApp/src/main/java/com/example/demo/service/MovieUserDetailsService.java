package com.example.demo.service;

import com.example.demo.domain.RegisteredUser;
import com.example.demo.dao.RegisteredUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

import static org.springframework.security.core.authority.AuthorityUtils.commaSeparatedStringToAuthorityList;

@Service
public class MovieUserDetailsService implements UserDetailsService {
    @Value("${demo.admin.password}")
    private String adminPasswordHash;

    @Autowired
    private RegisteredUserRepository registeredUserRepo;

    @Override
    public UserDetails loadUserByUsername(String username) {
        if ("admin".equals(username)) return new User(username, adminPasswordHash, commaSeparatedStringToAuthorityList("ROLE_ADMIN, ROLE_USER"));
        for (RegisteredUser r : registeredUserRepo.findAll()) {
            if (r.getUsername().equals(username))  return new User(username, r.getPassword(), authorities(username));
        }
        return null;
    }

    private List<GrantedAuthority> authorities(String username) {

        for (RegisteredUser r : registeredUserRepo.findAll()) {
            if (r.getUsername().equals(username)) return commaSeparatedStringToAuthorityList("ROLE_USER");
        }
        throw new UsernameNotFoundException("No user '" + username + "'");
    }
}
