package com.example.demo.service;

import com.example.demo.domain.RegisteredUser;

import java.util.List;
import java.util.Optional;

public interface RegisteredUserService {

    List<RegisteredUser> listAllUsers();

    RegisteredUser createRegisteredUser(RegisteredUser registeredUser);

    RegisteredUser fetchRegisteredUser(long id);

    Optional<RegisteredUser> findByRegisteredUserId(long id);

    RegisteredUser updateRegisteredUser(RegisteredUser person);

    RegisteredUser deleteRegisteredUser(long registeredUserId);

}
