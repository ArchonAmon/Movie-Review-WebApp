package com.example.demo.domain;

import javax.persistence.*;

@Entity
public class WorksOnMovie {

    @EmbeddedId
    private WorksOn id;

    @ManyToOne
    @MapsId ("movieIdWorks")
    private Movie movie;

    @ManyToOne
    @MapsId ("personIdWorks")
    private Person person;

    @ManyToOne
    @MapsId ("roleIdWorks")
    private Role role;

    public WorksOnMovie() {

    }

    public WorksOnMovie(WorksOn id, Movie movie, Person person, Role role) {
        this.id = id;
        this.person = person;
        this.movie = movie;
        this.role = role;
    }


    public WorksOn getId() {
        return id;
    }

    public void setId(WorksOn id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
