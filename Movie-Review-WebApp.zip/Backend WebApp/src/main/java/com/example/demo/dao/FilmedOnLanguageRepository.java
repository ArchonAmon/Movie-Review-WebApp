package com.example.demo.dao;

import com.example.demo.domain.FilmedOnLanguage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilmedOnLanguageRepository extends JpaRepository<FilmedOnLanguage, Long> {

    //int countByMovieIdLang(long movieIdLang);

    //int countByLanguageIdLang(long languageIdLang);

    //List<FilmedOnLanguage> findAllBy(long movieIdLang);

}
