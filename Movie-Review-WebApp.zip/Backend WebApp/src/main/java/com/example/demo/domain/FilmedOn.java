package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class FilmedOn implements Serializable {

    @Column
    private Long movieIdLang;

    @Column
    private Long languageIdLang;


    public FilmedOn() {
    }

    public FilmedOn(long movieIdLang, long languageIdLang) {
        this.movieIdLang = movieIdLang;
        this.languageIdLang = languageIdLang;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FilmedOn filmedOn = (FilmedOn) o;
        return movieIdLang.equals(filmedOn.movieIdLang) &&
                languageIdLang.equals(filmedOn.languageIdLang);
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieIdLang, languageIdLang);
    }


    public Long getMovieIdLang() {
        return movieIdLang;
    }

    public Long getLanguageIdLang() {
        return languageIdLang;
    }

    public void setMovieIdLang(Long movieIdLang) {
        this.movieIdLang = movieIdLang;
    }

    public void setLanguageIdLang(Long languageIdLang) {
        this.languageIdLang = languageIdLang;
    }

}
