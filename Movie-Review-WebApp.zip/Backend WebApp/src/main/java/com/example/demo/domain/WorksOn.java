package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class WorksOn implements Serializable {

    @Column
    private Long movieIdWorks;

    @Column
    private Long personIdWorks;

    @Column
    private Long roleIdWorks;

    public WorksOn() {
    }

    public WorksOn(long movieIdWorks, long personIdWorks, long roleIdWorks) {
        this.movieIdWorks = movieIdWorks;
        this.personIdWorks = personIdWorks;
        this.roleIdWorks = roleIdWorks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorksOn worksOn = (WorksOn) o;
        return movieIdWorks.equals(worksOn.movieIdWorks) &&
                personIdWorks.equals(worksOn.personIdWorks) &&
                roleIdWorks.equals(worksOn.roleIdWorks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieIdWorks, personIdWorks, roleIdWorks);
    }


    public Long getMovieIdWorks() {
        return movieIdWorks;
    }

    public void setMovieIdWorks(Long movieIdWorks) {
        this.movieIdWorks = movieIdWorks;
    }

    public Long getPersonIdWorks() {
        return personIdWorks;
    }

    public void setPersonIdWorks(Long personIdWorks) {
        this.personIdWorks = personIdWorks;
    }

    public Long getRoleIdWorks() {
        return roleIdWorks;
    }

    public void setRoleIdWorks(Long roleIdWorks) {
        this.roleIdWorks = roleIdWorks;
    }
}
