package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class FilmedIn implements Serializable {

    @Column
    private Long movieIdCount;

    @Column
    private Long countryIdCount;

    public FilmedIn() {
    }

    public FilmedIn(long movieIdCount, long countryIdCount) {
        this.movieIdCount = movieIdCount;
        this.countryIdCount = countryIdCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FilmedIn filmedIn = (FilmedIn) o;
        return movieIdCount.equals(filmedIn.movieIdCount) &&
                countryIdCount.equals(filmedIn.countryIdCount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieIdCount, countryIdCount);
    }

    public Long getMovieIdCount() {
        return movieIdCount;
    }

    public void setMovieIdCount(Long movieIdCount) {
        this.movieIdCount = movieIdCount;
    }

    public Long getCountryIdCount() {
        return countryIdCount;
    }

    public void setCountryIdCount(Long countryIdCount) {
        this.countryIdCount = countryIdCount;
    }
}
