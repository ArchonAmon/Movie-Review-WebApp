package com.example.demo.service;

import com.example.demo.domain.Movie;

import java.util.List;
import java.util.Optional;

public interface MovieService {
    List<Movie> listAll(String username);

    //List<Movie> listAllByDirector();

    List<Movie> listForUserSearch(String name, String username);

    Movie createMovie(Movie movie);

    String createMovieTemplate(String link, String username);

    Movie fetch(long id, String username);

    Optional<Movie> findById(long id);

    Movie updateMovie(Movie movie, String username);

    Movie deleteMovie(long movieId, String username);

    List<Movie> listAllByTitle(String username);

    //List<Movie> listAllByLeadActor();

    List<Movie> listAllByIMDbRating(String username);

    List<Movie> listAllMyRating(String username);

    //List<Movie> listAllByWriter();

    List<Movie> listAllByYear(String username);

    List<Movie> listAllByDuration(String username);
}
