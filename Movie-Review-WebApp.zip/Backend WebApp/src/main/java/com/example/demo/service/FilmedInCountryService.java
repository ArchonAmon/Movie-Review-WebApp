package com.example.demo.service;

import com.example.demo.domain.FilmedInCountry;

import java.util.Optional;

public interface FilmedInCountryService {

    FilmedInCountry createFilmedInCountry(FilmedInCountry filmedInCountry);

    Optional<FilmedInCountry> findByMovieIdCount(long movieIdCount);

    Optional<FilmedInCountry> findByLanguageIdCount(long languageIdCount);

    //FilmedInCountry deleteFilmedInCountry(long movieIdCount, long languageIdCount);

}
