package com.example.demo.dao;

import com.example.demo.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {           //required for working with the DB

    int countById(long id);

    int countByCatName(String name);

    //long maxId();

}