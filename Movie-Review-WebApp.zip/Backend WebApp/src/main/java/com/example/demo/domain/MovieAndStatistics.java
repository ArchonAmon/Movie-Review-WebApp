package com.example.demo.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;
import java.util.Set;


public class MovieAndStatistics {

    private List<Movie> mov;

    private String statistics = "";

    public MovieAndStatistics() {

    }

    public MovieAndStatistics(List<Movie> mov, String statistics) {
        this.mov = mov;
        this.statistics = statistics;
    }

    public List<Movie> getMov() {
        return mov;
    }

    public void setMov(List<Movie> mov) {
        this.mov = mov;
    }

    public String getStatistics() {
        return statistics;
    }

    public void setStatistics(String statistics) {
        this.statistics = statistics;
    }
}
