package com.example.demo.domain;

import com.example.demo.domain.FilmedOnLanguage;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
public class Language {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    @Size(max = 50)
    private String langName;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "language")
    Set<FilmedOnLanguage> filmedOnLanguage;

    public Language() {

    }

    public Language(Long id, String langName) {
        this.id = id;
        this.langName = langName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLangName() {
        return langName;
    }

    public void setLangName(String langName) {
        this.langName = langName;
    }
}
