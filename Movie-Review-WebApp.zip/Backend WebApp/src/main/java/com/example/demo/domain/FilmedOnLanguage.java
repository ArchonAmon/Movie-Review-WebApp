package com.example.demo.domain;

import javax.persistence.*;

@Entity
public class FilmedOnLanguage {

    @EmbeddedId
    private FilmedOn id;

    @ManyToOne
    @MapsId ("movieIdLang")
    private Movie movie;

    @ManyToOne
    @MapsId ("languageIdLang")
    private Language language;

    public FilmedOnLanguage() {

    }

    public FilmedOnLanguage(FilmedOn id, Movie movie, Language language) {
        this.id = id;
        this.language = language;
        this.movie = movie;
    }

    public FilmedOn getId() {
        return id;
    }

    public void setId(FilmedOn id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }
}
