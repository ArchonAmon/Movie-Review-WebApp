package com.example.demo.domain;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.HashSet;

public class WholeMovie {

    private Long id;
    @Size(max = 1000)
    private String name = "";
    @Size(max = 2000)
    private String poster_url;
    @Size(max = 2000)
    private String link;
    @Max(10)
    @Min(0)
    private double IMDb_rating = 0;
    @Max(2100)
    @Min(1900)
    private int year = 0;

    @Size(max = 50000)
    private String review = "";
    private Date dateViewed = null;
    @Max(10)
    @Min(0)
    private int myRating = 0;
    private int duration = 0;
    private boolean movieAdded;

    private String countries;

    private String languages;

    private String categories;

    private String directors;

    private String writers;

    private String actors;

    public WholeMovie() {

    }

    public WholeMovie(Long id, String name, String poster_url, String link, @Max(10) @Min(0) double IMDb_rating, int year, String review, Date dateViewed, @Max(10) @Min(0) int myRating, int duration, boolean movieAdded, String countries, String languages, String categories, String directors, String writers, String actors) {
        this.id = id;
        this.name = name;
        this.poster_url = poster_url;
        this.link = link;
        this.IMDb_rating = IMDb_rating;
        this.year = year;
        this.review = review;
        this.dateViewed = dateViewed;
        this.myRating = myRating;
        this.duration = duration;
        this.movieAdded = movieAdded;
        this.countries = countries;
        this.languages = languages;
        this.categories = categories;
        this.directors = directors;
        this.writers = writers;
        this.actors = actors;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPoster_url() {
        return poster_url;
    }

    public void setPoster_url(String poster_url) {
        this.poster_url = poster_url;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public double getIMDb_rating() {
        return IMDb_rating;
    }

    public void setIMDb_rating(double IMDb_rating) {
        this.IMDb_rating = IMDb_rating;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Date getDateViewed() {
        return dateViewed;
    }

    public void setDateViewed(Date dateViewed) {
        this.dateViewed = dateViewed;
    }

    public int getMyRating() {
        return myRating;
    }

    public void setMyRating(int myRating) {
        this.myRating = myRating;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public boolean isMovieAdded() {
        return movieAdded;
    }

    public void setMovieAdded(boolean movieAdded) {
        this.movieAdded = movieAdded;
    }

    public String getCountries() {
        return countries;
    }

    public void setCountries(String countries) {
        this.countries = countries;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getDirectors() {
        return directors;
    }

    public void setDirectors(String directors) {
        this.directors = directors;
    }

    public String getWriters() {
        return writers;
    }

    public void setWriters(String writers) {
        this.writers = writers;
    }

    public String getActors() {
        return actors;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }
}
