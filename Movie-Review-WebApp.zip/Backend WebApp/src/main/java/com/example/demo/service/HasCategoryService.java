package com.example.demo.service;

import com.example.demo.domain.HasCategory;

import java.util.Optional;

public interface HasCategoryService {

    HasCategory createHasCategory(HasCategory hasCategory);

    Optional<HasCategory> findByMovieIdCat(long movieIdCat);

    Optional<HasCategory> findByCategoryIdCat(long categoryIdCat);

    //HasCategory deleteHasCategory(long movieIdCat, long categoryIdCat);

}
