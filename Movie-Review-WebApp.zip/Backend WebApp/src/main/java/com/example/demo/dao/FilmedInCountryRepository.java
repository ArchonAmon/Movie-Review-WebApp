package com.example.demo.dao;

import com.example.demo.domain.FilmedInCountry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilmedInCountryRepository extends JpaRepository<FilmedInCountry, Long> {

    //int countByMovieIdCount(long movieIdCount);

    //int countByCountryIdCount(long languageIdCount);

    //List<FilmedInCountry> findAllBy(long movieIdCount);

}
