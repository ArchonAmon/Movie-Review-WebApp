package com.example.demo.domain;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.Set;

@Entity
public class Movie {

    @Id
    @GeneratedValue
    private Long id;
    @Size(max = 1000)
    private String name = "";
    @Size(max = 2000)
    private String poster_url;
    @Size(max = 2000)
    private String link;
    @Max(10)
    @Min(0)
    private double IMDb_rating = 0;
    @Max(2100)
    @Min(1900)
    private int year = 0;

    @Size(max = 50000)
    private String review = "";
    private Date dateViewed = null;
    @Max(10)
    @Min(0)
    private int myRating = 0;
    private int duration = 0;
    private boolean movieAdded;


    @OneToMany (cascade = CascadeType.ALL, mappedBy = "movie")
    Set<WorksOnMovie> worksOnMovie;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "movie")
    Set<FilmedInCountry> filmedInCountry;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "movie")
    Set<FilmedOnLanguage> filmedOnLanguage;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "movie")
    Set<HasCategory> hasCategory;


    @JsonIgnore
    private String user;

    public Movie() {
    }

    public Movie(Long id, String name, String poster_url, String link, double imDb_rating, int myRating, int year, String review, Date dateViewed, int duration, boolean movieAdded, String user) {
        this.id = id;
        this.name = name;
        this.poster_url = poster_url;
        this.link = link;
        IMDb_rating = imDb_rating;
        this.myRating = myRating;
        this.year = year;
        this.review = review;
        this.dateViewed = dateViewed;
        this.movieAdded = movieAdded;
        this.duration = duration;
        this.user = user;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPoster_url() {
        return poster_url;
    }

    public void setPoster_url(String poster_url) {
        this.poster_url = poster_url;
    }

    public double getIMDb_rating() {
        return IMDb_rating;
    }

    public void setIMDb_rating(double IMDb_rating) {
        this.IMDb_rating = IMDb_rating;
    }

    public int getMyRating() {
        return myRating;
    }

    public void setMyRating(int myRating) {
        this.myRating = myRating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Date getDateViewed() {
        return dateViewed;
    }

    public void setDateViewed(Date dateViewed) {
        this.dateViewed = dateViewed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public boolean isMovieAdded() {
        return movieAdded;
    }

    public void setMovieAdded(boolean movieAdded) {
        this.movieAdded = movieAdded;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
            if (duration.contains("H") && !duration.contains("M")) {
                String[] hours = duration.split("H");
                this.duration = Integer.parseInt(hours[0]);           //parse the duration string here
            }
            else if (duration.contains("M") && duration.contains("H")) {
                String[] hoursAndMinutes = duration.split("M");
                String[] h = hoursAndMinutes[0].split("H");
                this.duration = Integer.parseInt(h[0]) * 60 + Integer.parseInt(h[1]);           //parse the duration string here
            }
            else if (!duration.contains("H") && duration.contains("M")) {
                String[] minutes = duration.split("M");
                this.duration = Integer.parseInt(minutes[0]);           //parse the duration string here
            }
            else {
                this.duration = 0;
                return;
            }
    }
}
