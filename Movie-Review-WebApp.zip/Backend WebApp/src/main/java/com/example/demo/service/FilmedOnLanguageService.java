package com.example.demo.service;

import com.example.demo.domain.FilmedOnLanguage;

import java.util.Optional;

public interface FilmedOnLanguageService {

    FilmedOnLanguage createFilmedOnLanguage(FilmedOnLanguage filmedOnLanguage);

    Optional<FilmedOnLanguage> findByMovieIdLang(long movieIdLang);

    Optional<FilmedOnLanguage> findByLanguageIdLang(long languageIdLang);

    //FilmedOnLanguage deleteFilmedOnLanguage(long movieIdLang, long languageIdLang);

}
