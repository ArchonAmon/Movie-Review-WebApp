package com.example.demo.domain;

import com.example.demo.domain.WorksOnMovie;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
public class Role {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    @Size(max = 50)
    private String roleName;

    @OneToMany (cascade = CascadeType.ALL, mappedBy = "role")
    Set<WorksOnMovie> worksOnMovie;

    public Role() {

    }

    public Role(Long id, String roleName) {
        this.id = id;
        this.roleName = roleName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
