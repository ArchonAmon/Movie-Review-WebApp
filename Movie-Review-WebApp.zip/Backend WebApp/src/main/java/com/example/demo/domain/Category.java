package com.example.demo.domain;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Set;

@Entity
public class Category {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true)
    @Size(max = 50)
    private String catName;


    @OneToMany (cascade = CascadeType.ALL, mappedBy = "category")
    Set<HasCategory> hasCategory;

    public Category() {

    }

    public Category(Long id, String catName) {
        this.id = id;
        this.catName = catName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }
}
