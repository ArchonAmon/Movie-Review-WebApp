package com.example.demo.dao;

import com.example.demo.domain.Language;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LanguageRepository extends JpaRepository<Language, Long> {           //required for working with the DB

    int countById(long id);

    int countByLangName(String name);

    //long maxId();

}