package com.example.demo.domain;

import javax.persistence.*;

@Entity
public class HasCategory {

    @EmbeddedId
    private HasCat id;

    @ManyToOne
    @MapsId ("movieIdCat")
    private Movie movie;

    @ManyToOne
    @MapsId ("categoryIdCat")
    private Category category;

    public HasCategory() {

    }

    public HasCategory(HasCat id, Movie movie, Category category) {
        this.id = id;
        this.category = category;
        this.movie = movie;
    }

    public HasCat getId() {
        return id;
    }

    public void setId(HasCat id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

}
