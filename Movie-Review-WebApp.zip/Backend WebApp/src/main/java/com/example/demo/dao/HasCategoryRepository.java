package com.example.demo.dao;

import com.example.demo.domain.HasCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HasCategoryRepository extends JpaRepository<HasCategory, Long> {

    //int countByMovieIdCat(long movieIdCat);

    //int countByCategoryIdCat(long languageIdCount);

    //List<HasCategory> findAllBy(long movieIdCat);

}
