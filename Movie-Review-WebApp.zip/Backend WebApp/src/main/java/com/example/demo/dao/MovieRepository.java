package com.example.demo.dao;

import com.example.demo.domain.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieRepository extends JpaRepository<Movie, Long> {           //required for working with the DB

    int countByName(String name);

    //int countByDirector(String director);

    //int countByWriter(String writer);

    int countById(long id);

    int countByLink(String link);

    //long maxId();

}
