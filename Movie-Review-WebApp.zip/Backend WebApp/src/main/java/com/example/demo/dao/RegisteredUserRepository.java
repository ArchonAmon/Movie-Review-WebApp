package com.example.demo.dao;

import com.example.demo.domain.RegisteredUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisteredUserRepository extends JpaRepository<RegisteredUser, Long> {           //required for working with the DB

    int countById(long id);

    int countByUsername(String userName);

    //long maxId();

}