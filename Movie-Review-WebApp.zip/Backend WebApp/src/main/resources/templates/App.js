import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { render } from '@testing-library/react';
import Top from './components/Top';
import MovieLibrary from './components/MovieLibrary';

class App extends Component {
    render() {
        return (
            <div className="App" style={{flex: 1, height: "100%", minHeight: "100%"}}>
                <Top></Top>
                <MovieLibrary></MovieLibrary>
            </div>
        );
    }
}


export default App;
