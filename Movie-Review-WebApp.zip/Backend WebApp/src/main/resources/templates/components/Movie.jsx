import React, { Component } from 'react';


//has a scroller, max 4-5 movies per row
//take the number of movies from the backend then create enough movie objects
//200px picture, 100px title
export default class Movie extends Component {
    render() {
        return(
            <div className="movieLibrary" style={{backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}>
            </div>
        );
    }
}