import React, { Component } from 'react';
import Movie from './Movie';


//has a scroller, max 4-5 movies per row
//take an array of movies from the backend and then iterate through the array, creating movie objects
//maybe make height max instead of px, maybe take px or max, whichever is bigger
export default class MovieLibrary extends Component {
    render() {
        return(
            <div className="movieLibrary" style={{backgroundColor: "red", width: "max", height: '590px', borderTop: "6px solid grey"}}>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
                <img id="mov" style={{float: "left", backgroundColor: "yellow", width: "150px", height: '200px', margin: "50px"}}></img>
            </div>
        );
    }
}




