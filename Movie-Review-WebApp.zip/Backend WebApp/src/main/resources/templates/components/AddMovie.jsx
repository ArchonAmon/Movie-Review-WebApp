import React, { Component } from 'react';

var IMDb_url = "//www.imdb.com/title/"
var providedUrl = "null"

function urlCheck() {
    if (!providedUrl.includes(IMDb_url)) {
        alert("This is not an IMDb movie url");
    }
    //call backend and check if the movie already exists
    else if (false) {
        alert("This movie was already added");
    }
    else {
        //call move siphon function and show AddMovie screen (route the user to the AddMovie screen, top stays, bottom is the filled
        //with the movie information fields and ready to write the review, date and grade)
        <Route path="/AddMovie">
            <AddMovie />
        </Route>
    }
}

const _handleChange = () => {
    providedUrl = document.getElementById("addon-wrapping").value
}


const _searchUrl = () => {
//call backend, but first check path of the url???
}

const _sortBoxChange = () => {
    //call MovieLibrary and sort it with a bunch of if, else if and else commands
}


//class component
//maybe add a logout icon in the right corner
export default class Top extends Component {
    render() {
        return(
            <div className="top" style={{width: 'max', height: '125px', backgroundImage: "url(https://acrediteounao.com/wp-content/uploads/2017/02/filmes.png)"}}>
                <div class="searchBox" style={{zIndex: 2}}>
                    <input type="text"
                           class="form-control" placeholder="Provide the IMDb url of the movie"  id ="addon-wrapping"
                           aria-label="url" aria-describedby="addon-wrapping" onChange={_handleChange} size="40"
                    />
                </div>
                <div class="searchButton">
                    <button type="button" onClick={urlCheck}>Add Movie</button>
                </div>
                <div onChange={_sortBoxChange} type="sortDropbox" class="sortDropbox" style={{position: "absolute", top: "100px", left:"0", width: "300px"}}>
                    <label for="sorter" style={{color: "white"}} >Sort by:</label>
                    <select id="sorts" name="sorts">
                        <option value="Title">Title</option>
                        <option value="IMDb rating">IMDb rating</option>
                        <option value="My rating" selected>My rating</option>
                        <option value="Date viewed">Date viewed</option>
                        <option value="Director">Director</option>
                        <option value="Writer">Writer</option>
                    </select>
                </div>
            </div>

        );
    }
}
